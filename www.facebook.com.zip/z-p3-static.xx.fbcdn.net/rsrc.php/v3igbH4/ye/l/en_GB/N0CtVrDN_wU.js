if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("ChatQuietLinks", ["DOM", "DataStore", "Event", "Parent", "UserAgent_DEPRECATED", "getOrCreateDOMID"], (function(a, b, c, d, e, f) {
    var g = {};
    a = {
        silenceLinks: function(a) {
            h(a, this.removeEmptyHrefs.bind(this))
        },
        nukeLinks: function(a) {
            h(a, this.removeAllHrefs.bind(this))
        },
        removeEmptyHrefs: function(a) {
            i(a, function(a) {
                return !a || a === "#"
            })
        },
        removeAllHrefs: function(a) {
            i(a)
        }
    };

    function h(a, c) {
        if (!a) return;
        var d = !!b("UserAgent_DEPRECATED").chrome(),
            e = !!b("UserAgent_DEPRECATED").chrome() || b("UserAgent_DEPRECATED").ie() >= 9 || b("UserAgent_DEPRECATED").firefox() >= 4;
        if (g[b("getOrCreateDOMID")(a)]) return;
        g[b("getOrCreateDOMID")(a)] = !0;
        if (!e) return;
        if (!d) {
            c && c(a);
            return
        }
        b("Event").listen(a, "mouseover", function(a) {
            a = b("Parent").byTag(a.getTarget(), "a");
            if (a) {
                var c = a.getAttribute("href");
                j(c) && (b("DataStore").set(a, "stashedHref", a.getAttribute("href")), a.removeAttribute("href"))
            }
        });
        b("Event").listen(a, "mouseout", function(a) {
            a = b("Parent").byTag(a.getTarget(), "a");
            var c = a && b("DataStore").remove(a, "stashedHref");
            j(c) && a.setAttribute("href", c)
        });
        b("Event").listen(a, "mousedown", function(a) {
            if (!a.isDefaultRequested()) return !0;
            a = b("Parent").byTag(a.getTarget(), "a");
            var c = a && b("DataStore").get(a, "stashedHref");
            j(c) && a.setAttribute("href", c)
        })
    }

    function i(a, c) {
        a = b("DOM").scry(a, "a");
        c && (a = a.filter(function(a) {
            return c(a.getAttribute("href"))
        }));
        a.forEach(function(a) {
            a.removeAttribute("href"), a.tabIndex || a.setAttribute("tabindex", 0)
        })
    }

    function j(a) {
        return a && a !== "#"
    }
    e.exports = a
}), null);
__d("Dock", ["csx", "ArbiterMixin", "BlueBar", "CSS", "ChatQuietLinks", "DOM", "DataStore", "Event", "Parent", "Scroll", "Style", "Toggler", "Vector", "emptyFunction", "isKeyActivation", "shield"], (function(a, b, c, d, e, f, g) {
    function c() {}
    Object.assign(c, b("ArbiterMixin"), {
        MIN_HEIGHT: 140,
        INITIAL_FLYOUT_HEIGHT_OFFSET: 10,
        init: function(a) {
            var c = this;
            this.init = b("emptyFunction");
            this.rootEl = a;
            this.calculateViewportDimensions();
            b("ChatQuietLinks").removeEmptyHrefs(this.rootEl);
            b("Event").listen(a, "click", this._onClick.bind(this));
            var d = a.querySelector(".fbNubButton");
            d && b("Event").listen(d, "keypress", this._onKeyPress.bind(this));
            b("Event").listen(window, "resize", this._onWindowResize.bind(this));
            b("Toggler").subscribe(["show", "hide"], function(d, e) {
                e = e.getActive();
                if (!b("DOM").contains(a, e)) return;
                if (b("CSS").hasClass(e, "fbNub")) c.notifyNub(e, d), d === "show" && c._resizeNubFlyout(e);
                else {
                    e = b("Parent").byClass(e, "fbNubFlyout");
                    e && b("CSS").conditionClass(e, "menuOpened", d === "show")
                }
            });
            this.inform("init", {}, "persistent")
        },
        calculateViewportDimensions: function() {
            return this.viewportDimensions = b("Vector").getViewportDimensions()
        },
        getFlyoutHeightOffset: function() {
            if (this.flyoutHeightOffset) return this.flyoutHeightOffset;
            this.flyoutHeightOffset = this.INITIAL_FLYOUT_HEIGHT_OFFSET + b("Vector").getElementDimensions(this.rootEl).y;
            var a = b("BlueBar").getBar();
            if (a) {
                var c = b("Style").isFixed(a) ? "viewport" : "document";
                this.flyoutHeightOffset += b("Vector").getElementPosition(a, c).y + b("Vector").getElementDimensions(a).y
            }
            return this.flyoutHeightOffset
        },
        toggle: function(a) {
            var c = this._findFlyout(a);
            if (!c) return;
            this.subscribe("init", function() {
                b("Toggler").toggle(a)
            })
        },
        show: function(a) {
            this.subscribe("init", function() {
                b("Toggler").show(a)
            })
        },
        showNub: function(a) {
            b("CSS").show(a)
        },
        hide: function(a) {
            this.subscribe("init", function() {
                var c = b("Toggler").getInstance(a);
                b("DOM").contains(a, c.getActive()) && c.hide()
            })
        },
        hideNub: function(a) {
            b("CSS").hide(a), this.hide(a)
        },
        setUseMaxHeight: function(a, c) {
            b("CSS").conditionClass(a, "maxHeight", c !== !1), this._resizeNubFlyout(a)
        },
        _resizeNubFlyout: function(a) {
            var c = this,
                d = this._findFlyout(a);
            if (!d || b("CSS").hasClass(a, "placeholder") || !(b("CSS").hasClass(a, "openToggler") || b("CSS").hasClass(a, "opened"))) return;
            var e = b("DOM").find(d, "div.fbNubFlyoutOuter"),
                f = b("DOM").find(e, "div.fbNubFlyoutInner"),
                g = b("DOM").find(f, "div.fbNubFlyoutBody"),
                h = b("CSS").hasClass(a, "canBeCompactTab"),
                i = b("Scroll").getTop(g),
                j = g.offsetHeight;
            b("Style").set(g, "height", "auto");
            var k = b("Vector").getElementDimensions(d),
                l = b("Vector").getElementDimensions(g),
                m = this.getMaxFlyoutHeight(a);
            b("Style").set(d, "max-height", m + "px");
            b("Style").set(e, "max-height", m + "px");
            k = b("Vector").getElementDimensions(d);
            e = b("Vector").getElementDimensions(f);
            m = e.y - l.y;
            f = k.y - m;
            e = parseInt(g.style.height || g.clientHeight, 10);
            e = f !== e;
            k.y > m && e && !h && b("Style").set(g, "height", f + "px");
            b("CSS").removeClass(d, "swapDirection");
            var n = b("Vector").getElementPosition(d).x;
            b("CSS").conditionClass(d, "swapDirection", function() {
                if (n < 0) return !0;
                return !k || !c.viewportDimensions ? !1 : n + k.x > c.viewportDimensions.x
            }());
            e && i + j >= l.y ? b("Scroll").setTop(g, g.scrollHeight) : b("Scroll").setTop(g, i);
            this.notifyNub(a, "resize")
        },
        getMaxFlyoutHeight: function(a) {
            a = this._findFlyout(a);
            var c = b("Vector").getElementPosition(a, "viewport");
            a = b("Vector").getElementDimensions(a);
            if (!this.viewportDimensions || !c) return 0;
            c = Math.max(this.MIN_HEIGHT, this.viewportDimensions.y - this.getFlyoutHeightOffset()) - (this.viewportDimensions.y - c.y - a.y);
            return Math.max(c, 0)
        },
        resizeAllFlyouts: function() {
            var a = this._getAllNubs(),
                b = a.length;
            while (b--) this._resizeNubFlyout(a[b])
        },
        _getAllNubs: function() {
            if (!this.rootEl) return [];
            var a = b("DOM").scry(this.rootEl, "div._50-v.openToggler:not(._s0f)");
            return a.concat(b("DOM").scry(this.rootEl, "div._50-v.opened:not(._s0f)"))
        },
        _onKeyPress: function(a) {
            var c = a.getTarget();
            c = b("Parent").byClass(c, "fbNub");
            b("isKeyActivation")(a) && c && this.toggle(c)
        },
        _onClick: function(a) {
            a = a.getTarget();
            var c = b("Parent").byClass(a, "fbNub");
            if (c) {
                b("Parent").byClass(a, "adsNubFlyoutCloseButton") && this.hide(c);
                if (b("Parent").byClass(a, "fbNubFlyoutTitlebar")) {
                    var d = b("Parent").byTag(a, "a");
                    a = a.nodeName == "INPUT" && a.getAttribute("type") == "submit";
                    if (!d && !a) {
                        this.hide(c);
                        return !1
                    }
                }
                this.notifyNub(c, "click")
            }
        },
        _onWindowResize: function(a) {
            this.calculateViewportDimensions(), this.resizeAllFlyouts()
        },
        _findFlyout: function(a) {
            return b("CSS").hasClass(a, "fbNubFlyout") ? a : b("DOM").scry(a, "div.fbNubFlyout")[0] || null
        },
        registerNubController: function(a, c) {
            b("DataStore").set(a, "dock:nub:controller", c), c.subscribe("nub/button/content-changed", b("shield")(this.inform, this, "resize", a)), c.subscribe("nub/flyout/content-changed", b("shield")(this._resizeNubFlyout, this, a))
        },
        unregisterNubController: function(a) {
            b("DataStore").remove(a, "dock:nub:controller")
        },
        notifyNub: function(a, c, d) {
            a = b("DataStore").get(a, "dock:nub:controller");
            a && a.inform(c, d)
        }
    });
    e.exports = a.Dock || c
}), null);
__d("KeyboardShortcutToken", ["KeyEventController"], (function(a, b, c, d, e, f, g) {
    a = function() {
        function a(a, b, c) {
            this.$1 = !0, this.key = a, this.handler = b, this.filter = c.filter, this.persistOnTransition = c.persistOnTransition, this.shortcutInfo = c.shortcutInfo, this.register()
        }
        var b = a.prototype;
        b.register = function() {
            var a = this;
            if (!this.$1) return;
            this.token = c("KeyEventController").registerKey(this.key, this.handler, this.filter, !1, function() {
                return a.persistOnTransition
            })
        };
        b.remove = function() {
            this.token.remove(), this.$1 = !1
        };
        b.unregister = function() {
            this.token.remove()
        };
        b.isActive = function() {
            return this.$1
        };
        b.getKey = function() {
            return this.key
        };
        b.getShortcutInfo = function() {
            return this.shortcutInfo
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("PageTransitions", ["cr:917439"], (function(a, b, c, d, e, f, g) {
    g["default"] = b("cr:917439")
}), 98);
__d("translateKey", ["fbt", "invariant"], (function(a, b, c, d, e, f, g, h, i) {
    var j = {
        alt: h._( /*FBT_CALL*/ "alt" /*FBT_CALL*/ ),
        enter: h._( /*FBT_CALL*/ "enter" /*FBT_CALL*/ ),
        "delete": h._( /*FBT_CALL*/ "delete" /*FBT_CALL*/ ),
        shift: h._( /*FBT_CALL*/ "shift" /*FBT_CALL*/ ),
        opt: h._( /*FBT_CALL*/ "opt" /*FBT_CALL*/ ),
        ctrl: h._( /*FBT_CALL*/ "ctrl" /*FBT_CALL*/ ),
        cmd: h._( /*FBT_CALL*/ "cmd" /*FBT_CALL*/ ),
        esc: h._( /*FBT_CALL*/ "esc" /*FBT_CALL*/ ),
        tab: h._( /*FBT_CALL*/ "tab" /*FBT_CALL*/ ),
        up: h._( /*FBT_CALL*/ "up" /*FBT_CALL*/ ),
        down: h._( /*FBT_CALL*/ "down" /*FBT_CALL*/ ),
        right: h._( /*FBT_CALL*/ "right" /*FBT_CALL*/ ),
        left: h._( /*FBT_CALL*/ "left" /*FBT_CALL*/ ),
        page_up: h._( /*FBT_CALL*/ "page up" /*FBT_CALL*/ ),
        page_down: h._( /*FBT_CALL*/ "page down" /*FBT_CALL*/ ),
        home: h._( /*FBT_CALL*/ "home" /*FBT_CALL*/ ),
        end: h._( /*FBT_CALL*/ "end" /*FBT_CALL*/ )
    };

    function a(a) {
        if (Object.prototype.hasOwnProperty.call(j, a)) return j[a];
        a.length === 1 || i(0, 2507);
        return a
    }
    g["default"] = a
}), 98);
__d("KeyboardShortcuts", ["csx", "cx", "fbt", "Arbiter", "BasicFBNux", "CSS", "Dock", "KeyEventController", "KeyboardShortcutToken", "Layer", "ModalLayer", "NavigationMessage", "PageTransitions", "Run", "emptyFunction", "translateKey"], (function(a, b, c, d, e, f, g, h, i, j) {
    var k = {
        _arbiter: null,
        _hasTriggeredShortcut: !1,
        _flyoutNub: null,
        _nubNux: null,
        _nubNuxID: null,
        _tokenLayers: [],
        showInfo: c("emptyFunction"),
        register: function(a, b, d) {
            var e = d ? d : {};
            d = function(a, c) {
                b.call(k, a, c), e.allowDefault || a.prevent(), k._hasTriggeredShortcut || k._handleFirstShortcutTriggered()
            };
            var f = e.baseFilters || [c("KeyEventController").defaultFilter],
                g = function(a, b) {
                    for (var c = f, d = Array.isArray(c), g = 0, c = d ? c : c[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                        var h;
                        if (d) {
                            if (g >= c.length) break;
                            h = c[g++]
                        } else {
                            g = c.next();
                            if (g.done) break;
                            h = g.value
                        }
                        h = h;
                        if (!h(a, b)) return !1
                    }
                    return !e.filter || e.filter(a, b)
                };
            a = new(c("KeyboardShortcutToken"))(a, d, {
                filter: g,
                persistOnTransition: e.persistOnTransition,
                shortcutInfo: e.shortcutInfo
            });
            k._tokenLayers.length || k._tokenLayers.push([]);
            k._tokenLayers[k._tokenLayers.length - 1].push(a);
            k.inform("token_added");
            return a
        },
        init: function() {
            k._cleanup = k._cleanup.bind(k), d("Run").onLeave(k._cleanup), c("Arbiter").subscribe(c("NavigationMessage").NAVIGATION_BEGIN, k._cleanup), c("Layer").subscribe("show", function(a, b) {
                b.hasBehavior(c("ModalLayer")) && k.pushLayer()
            }), c("Layer").subscribe("hide", function(a, b) {
                b.hasBehavior(c("ModalLayer")) && k.popLayer()
            }), k.register("SLASH", function() {
                var a = k._getFlyoutNub();
                a && c("Dock").toggle(a)
            }, {
                filter: function(a, b) {
                    return a.getModifiers().shift
                },
                persistOnTransition: !0,
                shortcutInfo: {
                    displayKeys: [c("translateKey")("?")],
                    description: j._( /*FBT_CALL*/ "Show this help dialogue" /*FBT_CALL*/ )
                }
            })
        },
        _cleanup: function() {
            var a = [];
            k._tokenLayers.forEach(function(b) {
                var c = [];
                b.forEach(function(a) {
                    a.isActive() && c.push(a)
                });
                c.length && a.push(c)
            });
            k._tokenLayers = a;
            k.inform("cleanup");
            c("PageTransitions").registerCompletionCallback(function() {
                d("Run").onLeave(k._cleanup), c("Arbiter").subscribe(c("NavigationMessage").NAVIGATION_BEGIN, k._cleanup)
            })
        },
        pushLayer: function() {
            var a = k._getTopLayer();
            a && a.forEach(function(a) {
                a.unregister()
            });
            k._tokenLayers.push([])
        },
        popLayer: function() {
            if (k._tokenLayers.length === 0) return;
            var a = k._tokenLayers.pop();
            a.forEach(function(a) {
                a.remove()
            });
            a = k._getTopLayer();
            a && a.forEach(function(a) {
                a.register()
            })
        },
        _getTopLayer: function() {
            return !k._tokenLayers.length ? null : k._tokenLayers[k._tokenLayers.length - 1]
        },
        _getBaseLayer: function() {
            return !k._tokenLayers.length ? null : k._tokenLayers[0]
        },
        getShortcutInfos: function() {
            var a = [],
                b = k._getBaseLayer();
            b && b.forEach(function(b) {
                var c = b.getShortcutInfo();
                b.isActive() && c != null && a.push(c)
            });
            return a
        },
        _getArbiterInstance: function() {
            k._arbiter || (k._arbiter = new(c("Arbiter"))());
            return k._arbiter
        },
        inform: function(a, b, c) {
            return k._getArbiterInstance().inform(a, b, c)
        },
        subscribe: function(a, b, c) {
            return k._getArbiterInstance().subscribe(a, b, c)
        },
        unsubscribe: function(a) {
            k._getArbiterInstance().unsubscribe(a)
        },
        _handleFirstShortcutTriggered: function() {
            k._hasTriggeredShortcut = !0;
            var a = k._getFlyoutNub();
            a && (d("CSS").removeClass(a, "_ur5"), k._nubNux && k._nubNuxID && (k._nubNux.show(), d("BasicFBNux").onView(k._nubNuxID), k._nubNux.subscribe("hide", d("BasicFBNux").onDismiss.bind(k, k._nubNuxID))))
        },
        _getFlyoutNub: function() {
            k._flyoutNub || (k._flyoutNub = document.querySelector("#pagelet_dock ._rz3"));
            return k._flyoutNub
        },
        showShortcutFlyout: function() {
            k._hasTriggeredShortcut || k._handleFirstShortcutTriggered();
            var a = k._getFlyoutNub();
            a && c("Dock").show(a)
        },
        hasFlyoutToShow: function() {
            return k._getFlyoutNub() != null && k.getShortcutInfos().length > 0
        },
        initNUXEvent: function(a, b) {
            k._nubNux = a, k._nubNuxID = b
        }
    };
    k.init();
    a = k;
    g["default"] = a
}), 98);
__d("FlipDirection", ["DOM", "Input", "Style"], (function(a, b, c, d, e, f) {
    a = {
        setDirection: function(a, c, d) {
            c === void 0 && (c = 5);
            d === void 0 && (d = !1);
            var e = b("DOM").isNodeOfType(a, "input") && a.type == "text",
                f = b("DOM").isNodeOfType(a, "textarea");
            if (!(e || f) || a.getAttribute("data-prevent-auto-flip")) return;
            e = b("Input").getValue(a);
            f = a.style && a.style.direction;
            if (!f || d) {
                f = 0;
                d = !0;
                for (var g = 0; g < e.length; g++) {
                    var h = e.charCodeAt(g);
                    if (h >= 48) {
                        d && (d = !1, f++);
                        if (h >= 1470 && h <= 1920) {
                            b("Style").set(a, "direction", "rtl");
                            a.setAttribute("dir", "rtl");
                            return
                        }
                        if (f == c) {
                            b("Style").set(a, "direction", "ltr");
                            a.setAttribute("dir", "ltr");
                            return
                        }
                    } else d = !0
                }
            } else e.length === 0 && (b("Style").set(a, "direction", ""), a.removeAttribute("dir"))
        }
    };
    e.exports = a
}), null);
__d("FullScreen", ["ArbiterMixin", "CSS", "Event", "Keys", "UserAgent", "UserAgent_DEPRECATED", "mixin", "throttle"], (function(a, b, c, d, e, f, g) {
    var h = {},
        i = !1;

    function j(a) {
        c("Event").getKeyCode(a) === c("Keys").ESC && a.stopPropagation()
    }

    function k() {
        i || (document.addEventListener("keydown", j, !0), i = !0)
    }

    function l() {
        i && (document.removeEventListener("keydown", j, !0), i = !1)
    }
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b, c;
            for (var e = arguments.length, f = new Array(e), g = 0; g < e; g++) f[g] = arguments[g];
            return (b = c = a.call.apply(a, [this].concat(f)) || this, c.onChange = function() {
                var a = c.isFullScreen(),
                    b = document.body;
                b && d("CSS").conditionClass(b, "fullScreen", a);
                c.inform("changed");
                a || l()
            }, b) || babelHelpers.assertThisInitialized(c)
        }
        var e = b.prototype;
        e.listenForEvent = function(a) {
            var b = c("throttle")(this.onChange, 0, this);
            h[a.id] || (h[a.id] = !0, c("Event").listen(a, {
                webkitfullscreenchange: b,
                mozfullscreenchange: b,
                MSFullscreenChange: b,
                fullscreenchange: b
            }))
        };
        e.enableFullScreen = function(a) {
            this.listenForEvent(a);
            a = a;
            if (a.webkitRequestFullScreen) d("UserAgent_DEPRECATED").chrome() ? a.webkitRequestFullScreen == null ? void 0 : a.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT) : a.webkitRequestFullScreen == null ? void 0 : a.webkitRequestFullScreen();
            else if (a.mozRequestFullScreen) a.mozRequestFullScreen();
            else if (a.msRequestFullscreen) k(), a.msRequestFullscreen == null ? void 0 : a.msRequestFullscreen();
            else if (a.requestFullScreen) a.requestFullScreen == null ? void 0 : a.requestFullScreen();
            else return !1;
            return !0
        };
        e.disableFullScreen = function() {
            var a = document;
            if (a.webkitCancelFullScreen) a.webkitCancelFullScreen();
            else if (a.mozCancelFullScreen) a.mozCancelFullScreen();
            else if (a.msExitFullscreen) a.msExitFullscreen();
            else if (a.cancelFullScreen) a.cancelFullScreen();
            else if (a.exitFullScreen) a.exitFullScreen();
            else return !1;
            return !0
        };
        e.isFullScreen = function() {
            var a = document;
            return Boolean(a.webkitIsFullScreen || a.fullScreen || a.mozFullScreen || a.msFullscreenElement)
        };
        e.toggleFullScreen = function(a) {
            if (this.isFullScreen()) {
                this.disableFullScreen();
                return !1
            } else return this.enableFullScreen(a)
        };
        e.isSupportedWithKeyboardInput = function() {
            return this.isSupported() && !c("UserAgent").isBrowser("Safari")
        };
        e.isSupported = function() {
            var a = document,
                b = a.webkitFullscreenEnabled || a.mozFullScreenEnabled || a.msFullscreenEnabled || a.fullscreenEnabled;
            return Boolean(b || a.webkitCancelFullScreen || a.mozCancelFullScreen || a.msExitFullscreen || a.cancelFullScreen || a.exitFullScreen)
        };
        return b
    }(c("mixin")(c("ArbiterMixin")));
    b = new a();
    e = c("throttle")(b.onChange, 0, b);
    c("Event").listen(document, {
        webkitfullscreenchange: e,
        mozfullscreenchange: e,
        MSFullscreenChange: e,
        fullscreenchange: e
    });
    f = b;
    g["default"] = f
}), 98);
__d("UITinyViewportAction", ["Arbiter", "ArbiterMixin", "CSS", "Event", "FullScreen", "getDocumentScrollElement", "queryThenMutateDOM", "throttle"], (function(a, b, c, d, e, f) {
    var g = document.documentElement,
        h, i, j, k, l = !1,
        m = !1,
        n = !1,
        o = {
            init: function(a) {
                a = b("throttle")(function() {
                    if (b("FullScreen").isFullScreen()) return;
                    b("queryThenMutateDOM")(function() {
                        k = k || b("getDocumentScrollElement")(), i = g.clientWidth < k.scrollWidth - 1, j = g.clientHeight < 400, h = j || i
                    }, function() {
                        if (h !== l || i !== m || j !== n) {
                            var a;
                            (a = b("CSS")).conditionClass(g, "tinyViewport", h);
                            a.conditionClass(g, "tinyWidth", i);
                            a.conditionClass(g, "tinyHeight", j);
                            a.conditionClass(g, "canHaveFixedElements", !h);
                            o.inform("change", h);
                            b("Arbiter").inform("tinyViewport/change", {
                                tiny: h,
                                tinyWidth: i,
                                tinyHeight: j
                            }, "state");
                            l = h;
                            m = i;
                            n = j
                        }
                    }, "TinyViewport")
                });
                a();
                b("Arbiter").subscribe("quickling/response", a);
                b("Event").listen(window, "resize", a);
                b("FullScreen").subscribe("changed", a)
            },
            isTiny: function() {
                return h
            },
            isTinyWidth: function() {
                return i
            },
            isTinyHeight: function() {
                return j
            }
        };
    Object.assign(o, b("ArbiterMixin"));
    e.exports = o
}), null);
__d("Animation", ["BrowserSupport", "CSS", "DOM", "DataStore", "Style", "clearInterval", "clearTimeout", "getVendorPrefixedName", "requestAnimationFrame", "setIntervalAcrossTransitions", "setTimeoutAcrossTransitions", "shield"], (function(a, b, c, d, e, f) {
    var g = b("requestAnimationFrame"),
        h = [],
        i;

    function j(b) {
        if (a == this) return new j(b);
        else this.obj = b, this._reset_state(), this.queue = [], this.last_attr = null, this.unit = "px", this.behaviorOverrides = {
            ignoreUserScroll: !1
        }
    }

    function k(a) {
        if (b("BrowserSupport").hasCSS3DTransforms()) return n(a);
        else return m(a)
    }

    function l(a) {
        return a.toFixed(8)
    }

    function m(a) {
        a = [a[0], a[4], a[1], a[5], a[12], a[13]];
        return "matrix(" + a.map(l).join(",") + ")"
    }

    function n(a) {
        return "matrix3d(" + a.map(l).join(",") + ")"
    }

    function o(a, b) {
        a || (a = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
        var c = [];
        for (var d = 0; d < 4; d++)
            for (var e = 0; e < 4; e++) {
                var f = 0;
                for (var g = 0; g < 4; g++) f += a[d * 4 + g] * b[g * 4 + e];
                c[d * 4 + e] = f
            }
        return c
    }
    var p = 0;
    j.prototype._reset_state = function() {
        this.state = {
            attrs: {},
            duration: 500
        }
    };
    j.prototype.stop = function() {
        this._reset_state();
        this.queue = [];
        return this
    };
    j.prototype._build_container = function() {
        if (this.container_div) {
            this._refresh_container();
            return
        }
        if (this.obj.firstChild && this.obj.firstChild.__animation_refs) {
            this.container_div = this.obj.firstChild;
            this.container_div.__animation_refs++;
            this._refresh_container();
            return
        }
        var a = document.createElement("div");
        a.style.padding = "0px";
        a.style.margin = "0px";
        a.style.border = "0px";
        a.__animation_refs = 1;
        var b = this.obj.childNodes;
        while (b.length) a.appendChild(b[0]);
        this.obj.appendChild(a);
        this._orig_overflow = this.obj.style.overflow;
        this.obj.style.overflow = "hidden";
        this.container_div = a;
        this._refresh_container()
    };
    j.prototype._refresh_container = function() {
        this.container_div.style.height = "auto", this.container_div.style.width = "auto", this.container_div.style.height = this.container_div.offsetHeight + this.unit, this.container_div.style.width = this.container_div.offsetWidth + this.unit
    };
    j.prototype._destroy_container = function() {
        if (!this.container_div) return;
        if (!--this.container_div.__animation_refs) {
            var a = this.container_div.childNodes;
            while (a.length) this.obj.appendChild(a[0]);
            this.obj.removeChild(this.container_div)
        }
        this.container_div = null;
        this.obj.style.overflow = this._orig_overflow
    };
    var q = 1,
        r = 2,
        s = 3;
    j.prototype._attr = function(a, b, c) {
        a = a.replace(/-[a-z]/gi, function(a) {
            return a.substring(1).toUpperCase()
        });
        var d = !1;
        switch (a) {
            case "background":
                this._attr("backgroundColor", b, c);
                return this;
            case "backgroundColor":
            case "borderColor":
            case "color":
                b = w(b);
                break;
            case "opacity":
                b = parseFloat(b, 10);
                break;
            case "height":
            case "width":
                b == "auto" ? d = !0 : b = parseInt(b, 10);
                break;
            case "borderWidth":
            case "lineHeight":
            case "fontSize":
            case "margin":
            case "marginBottom":
            case "marginLeft":
            case "marginRight":
            case "marginTop":
            case "padding":
            case "paddingBottom":
            case "paddingLeft":
            case "paddingRight":
            case "paddingTop":
            case "bottom":
            case "left":
            case "right":
            case "top":
            case "scrollTop":
            case "scrollLeft":
                b = parseInt(b, 10);
                break;
            case "rotateX":
            case "rotateY":
            case "rotateZ":
                b = parseInt(b, 10) * Math.PI / 180;
                break;
            case "translateX":
            case "translateY":
            case "translateZ":
            case "scaleX":
            case "scaleY":
            case "scaleZ":
                b = parseFloat(b, 10);
                break;
            case "rotate3d":
                this._attr("rotateX", b[0], c);
                this._attr("rotateY", b[1], c);
                this._attr("rotateZ", b[2], c);
                return this;
            case "rotate":
                this._attr("rotateZ", b, c);
                return this;
            case "scale3d":
                this._attr("scaleZ", b[2], c);
            case "scale":
                this._attr("scaleX", b[0], c);
                this._attr("scaleY", b[1], c);
                return this;
            case "translate3d":
                this._attr("translateZ", b[2], c);
            case "translate":
                this._attr("translateX", b[0], c);
                this._attr("translateY", b[1], c);
                return this;
            default:
                throw new Error(a + " is not a supported attribute!")
        }
        this.state.attrs[a] === void 0 && (this.state.attrs[a] = {});
        d && (this.state.attrs[a].auto = !0);
        switch (c) {
            case s:
                this.state.attrs[a].start = b;
                break;
            case r:
                this.state.attrs[a].by = !0;
            case q:
                this.state.attrs[a].value = b;
                break
        }
    };

    function t(a) {
        var c, d = parseInt((c = b("Style")).get(a, "paddingLeft"), 10),
            e = parseInt(c.get(a, "paddingRight"), 10),
            f = parseInt(c.get(a, "borderLeftWidth"), 10);
        c = parseInt(c.get(a, "borderRightWidth"), 10);
        return a.offsetWidth - (d ? d : 0) - (e ? e : 0) - (f ? f : 0) - (c ? c : 0)
    }

    function u(a) {
        var c, d = parseInt((c = b("Style")).get(a, "paddingTop"), 10),
            e = parseInt(c.get(a, "paddingBottom"), 10),
            f = parseInt(c.get(a, "borderTopWidth"), 10);
        c = parseInt(c.get(a, "borderBottomWidth"), 10);
        return a.offsetHeight - (d ? d : 0) - (e ? e : 0) - (f ? f : 0) - (c ? c : 0)
    }
    j.prototype.setUnit = function(a) {
        this.unit = a;
        return this
    };
    j.prototype.to = function(a, b) {
        b === void 0 ? this._attr(this.last_attr, a, q) : (this._attr(a, b, q), this.last_attr = a);
        return this
    };
    j.prototype.by = function(a, b) {
        b === void 0 ? this._attr(this.last_attr, a, r) : (this._attr(a, b, r), this.last_attr = a);
        return this
    };
    j.prototype.from = function(a, b) {
        b === void 0 ? this._attr(this.last_attr, a, s) : (this._attr(a, b, s), this.last_attr = a);
        return this
    };
    j.prototype.duration = function(a) {
        this.state.duration = a ? a : 0;
        return this
    };
    j.prototype.checkpoint = function(a, b) {
        a === void 0 && (a = 1);
        this.state.checkpoint = a;
        this.queue.push(this.state);
        this._reset_state();
        this.state.checkpointcb = b;
        return this
    };
    j.prototype.blind = function() {
        this.state.blind = !0;
        return this
    };
    j.prototype.hide = function() {
        this.state.hide = !0;
        return this
    };
    j.prototype.show = function() {
        this.state.show = !0;
        return this
    };
    j.prototype.ease = function(a) {
        this.state.ease = a;
        return this
    };
    j.prototype.CSSAnimation = function(a) {
        var b = {
            duration: this.state.duration
        };
        this.state.ondone && (b.callback = this.state.ondone);
        a(this.obj, b)
    };
    j.prototype.go = function() {
        var a = Date.now();
        this.queue.push(this.state);
        for (var b = 0; b < this.queue.length; b++) this.queue[b].start = a - p, this.queue[b].checkpoint && (a += this.queue[b].checkpoint * this.queue[b].duration);
        x(this);
        return this
    };
    j.prototype._show = function() {
        b("CSS").show(this.obj)
    };
    j.prototype._hide = function() {
        b("CSS").hide(this.obj)
    };
    j.prototype.overrideBehavior = function(a) {
        this.behaviorOverrides = babelHelpers["extends"]({}, this.behaviorOverrides, a);
        return this
    };
    j.prototype._frame = function(c) {
        var d = !0,
            e = !1,
            f;

        function g(a) {
            return document.documentElement[a] || document.body[a]
        }

        function h(a, b) {
            return a === document.body ? g(b) : a[b]
        }

        function i(a, b) {
            return b.lastScrollTop !== void 0 && b.lastScrollTop !== h(a.obj, "scrollTop") || b.lastScrollLeft !== void 0 && b.lastScrollLeft !== h(a.obj, "scrollLeft")
        }

        function j(a, b) {
            b.lastScrollTop = h(a.obj, "scrollTop"), b.lastScrollLeft = h(a.obj, "scrollLeft")
        }
        for (var l = 0; l < this.queue.length; l++) {
            var m = this.queue[l];
            if (m.start > c) {
                d = !1;
                continue
            }
            m.checkpointcb && (this._callback(m.checkpointcb, c - m.start), m.checkpointcb = null);
            if (m.started === void 0) {
                m.show && this._show();
                for (var n in m.attrs) {
                    if (m.attrs[n].start !== void 0) continue;
                    switch (n) {
                        case "backgroundColor":
                        case "borderColor":
                        case "color":
                            f = w(b("Style").get(this.obj, n == "borderColor" ? "borderLeftColor" : n));
                            m.attrs[n].by && (m.attrs[n].value[0] = Math.min(255, Math.max(0, m.attrs[n].value[0] + f[0])), m.attrs[n].value[1] = Math.min(255, Math.max(0, m.attrs[n].value[1] + f[1])), m.attrs[n].value[2] = Math.min(255, Math.max(0, m.attrs[n].value[2] + f[2])));
                            break;
                        case "opacity":
                            f = b("Style").getOpacity(this.obj);
                            m.attrs[n].by && (m.attrs[n].value = Math.min(1, Math.max(0, m.attrs[n].value + f)));
                            break;
                        case "height":
                            f = u(this.obj);
                            m.attrs[n].by && (m.attrs[n].value += f);
                            break;
                        case "width":
                            f = t(this.obj);
                            m.attrs[n].by && (m.attrs[n].value += f);
                            break;
                        case "scrollLeft":
                        case "scrollTop":
                            f = h(this.obj, n);
                            m.attrs[n].by && (m.attrs[n].value += f);
                            j(this, m);
                            break;
                        case "rotateX":
                        case "rotateY":
                        case "rotateZ":
                        case "translateX":
                        case "translateY":
                        case "translateZ":
                            f = b("DataStore").get(this.obj, n, 0);
                            m.attrs[n].by && (m.attrs[n].value += f);
                            break;
                        case "scaleX":
                        case "scaleY":
                        case "scaleZ":
                            f = b("DataStore").get(this.obj, n, 1);
                            m.attrs[n].by && (m.attrs[n].value += f);
                            break;
                        default:
                            f = parseInt(b("Style").get(this.obj, n), 10) || 0;
                            m.attrs[n].by && (m.attrs[n].value += f);
                            break
                    }
                    m.attrs[n].start = f
                }
                if (m.attrs.height && m.attrs.height.auto || m.attrs.width && m.attrs.width.auto) {
                    this._destroy_container();
                    for (var n in {
                            height: 1,
                            width: 1,
                            fontSize: 1,
                            borderLeftWidth: 1,
                            borderRightWidth: 1,
                            borderTopWidth: 1,
                            borderBottomWidth: 1,
                            paddingLeft: 1,
                            paddingRight: 1,
                            paddingTop: 1,
                            paddingBottom: 1
                        }) m.attrs[n] && (this.obj.style[n] = m.attrs[n].value + (typeof m.attrs[n].value === "number" ? this.unit : ""));
                    m.attrs.height && m.attrs.height.auto && (m.attrs.height.value = u(this.obj));
                    m.attrs.width && m.attrs.width.auto && (m.attrs.width.value = t(this.obj))
                }
                m.started = !0;
                m.blind && this._build_container()
            }
            var p = (c - m.start) / m.duration;
            p >= 1 ? (p = 1, m.hide && this._hide()) : d = !1;
            var q = m.ease ? m.ease(p) : p;
            !e && p != 1 && m.blind && (e = !0);
            for (var n in m.attrs) switch (n) {
                case "backgroundColor":
                case "borderColor":
                case "color":
                    m.attrs[n].start[3] != m.attrs[n].value[3] ? this.obj.style[n] = "rgba(" + v(q, m.attrs[n].start[0], m.attrs[n].value[0], !0) + "," + v(q, m.attrs[n].start[1], m.attrs[n].value[1], !0) + "," + v(q, m.attrs[n].start[2], m.attrs[n].value[2], !0) + "," + v(q, m.attrs[n].start[3], m.attrs[n].value[3], !1) + ")" : this.obj.style[n] = "rgb(" + v(q, m.attrs[n].start[0], m.attrs[n].value[0], !0) + "," + v(q, m.attrs[n].start[1], m.attrs[n].value[1], !0) + "," + v(q, m.attrs[n].start[2], m.attrs[n].value[2], !0) + ")";
                    break;
                case "opacity":
                    b("Style").set(this.obj, "opacity", v(q, m.attrs[n].start, m.attrs[n].value));
                    break;
                case "height":
                case "width":
                    this.obj.style[n] = q == 1 && m.attrs[n].auto ? "auto" : v(q, m.attrs[n].start, m.attrs[n].value, !0) + this.unit;
                    break;
                case "scrollLeft":
                case "scrollTop":
                    var r = this.obj === document.body;
                    if (!this.behaviorOverrides.ignoreUserScroll && i(this, m)) delete m.attrs.scrollTop, delete m.attrs.scrollLeft;
                    else {
                        var s = v(q, m.attrs[n].start, m.attrs[n].value, !0);
                        !r ? this.obj[n] = s : n == "scrollLeft" ? a.scrollTo(s, g("scrollTop")) : a.scrollTo(g("scrollLeft"), s);
                        j(this, m)
                    }
                    break;
                case "translateX":
                case "translateY":
                case "translateZ":
                case "rotateX":
                case "rotateY":
                case "rotateZ":
                case "scaleX":
                case "scaleY":
                case "scaleZ":
                    b("DataStore").set(this.obj, n, v(q, m.attrs[n].start, m.attrs[n].value, !1));
                    break;
                default:
                    this.obj.style[n] = v(q, m.attrs[n].start, m.attrs[n].value, !0) + this.unit;
                    break
            }
            r = null;
            s = b("DataStore").get(this.obj, "translateX", 0);
            n = b("DataStore").get(this.obj, "translateY", 0);
            q = b("DataStore").get(this.obj, "translateZ", 0);
            (s || n || q) && (r = o(r, [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, s, n, q, 1]));
            s = b("DataStore").get(this.obj, "scaleX", 1);
            n = b("DataStore").get(this.obj, "scaleY", 1);
            q = b("DataStore").get(this.obj, "scaleZ", 1);
            (s - 1 || n - 1 || q - 1) && (r = o(r, [s, 0, 0, 0, 0, n, 0, 0, 0, 0, q, 0, 0, 0, 0, 1]));
            s = b("DataStore").get(this.obj, "rotateX", 0);
            s && (r = o(r, [1, 0, 0, 0, 0, Math.cos(s), Math.sin(-s), 0, 0, Math.sin(s), Math.cos(s), 0, 0, 0, 0, 1]));
            n = b("DataStore").get(this.obj, "rotateY", 0);
            n && (r = o(r, [Math.cos(n), 0, Math.sin(n), 0, 0, 1, 0, 0, Math.sin(-n), 0, Math.cos(n), 0, 0, 0, 0, 1]));
            q = b("DataStore").get(this.obj, "rotateZ", 0);
            q && (r = o(r, [Math.cos(q), Math.sin(-q), 0, 0, Math.sin(q), Math.cos(q), 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]));
            s = b("getVendorPrefixedName")("transform");
            if (s)
                if (r) {
                    n = k(r);
                    b("Style").set(this.obj, s, n)
                } else d && b("Style").set(this.obj, s, null);
            p == 1 && (this.queue.splice(l--, 1), this._callback(m.ondone, c - m.start - m.duration))
        }!e && this.container_div && this._destroy_container();
        return !d
    };
    j.prototype.ondone = function(a) {
        this.state.ondone = a;
        return this
    };
    j.prototype._callback = function(a, b) {
        a && (p = b, a.call(this), p = 0)
    };

    function v(a, b, c, d) {
        return (d ? parseInt : parseFloat)((c - b) * a + b, 10)
    }

    function w(a) {
        var b = /^#([a-f0-9]{1,2})([a-f0-9]{1,2})([a-f0-9]{1,2})$/i.exec(a);
        if (b) return [parseInt(b[1].length == 1 ? b[1] + b[1] : b[1], 16), parseInt(b[2].length == 1 ? b[2] + b[2] : b[2], 16), parseInt(b[3].length == 1 ? b[3] + b[3] : b[3], 16), 1];
        else {
            b = /^rgba? *\(([0-9]+), *([0-9]+), *([0-9]+)(?:, *([0-9\.]+))?\)$/.exec(a);
            if (b) return [parseInt(b[1], 10), parseInt(b[2], 10), parseInt(b[3], 10), b[4] ? parseFloat(b[4]) : 1];
            else if (a == "transparent") return [255, 255, 255, 0];
            else throw new Error("Named color attributes are not supported.")
        }
    }

    function x(a) {
        h.push(a), h.length === 1 && (g ? g(z) : i = b("setIntervalAcrossTransitions")(z, 20)), g && y(), z(Date.now(), !0)
    }

    function y() {
        if (!g) throw new Error("Ending timer only valid with requestAnimationFrame");
        var a = 0;
        for (var c = 0; c < h.length; c++) {
            var d = h[c];
            for (var e = 0; e < d.queue.length; e++) {
                var f = d.queue[e].start + d.queue[e].duration;
                f > a && (a = f)
            }
        }
        i && (b("clearTimeout")(i), i = null);
        f = Date.now();
        a > f && (i = b("setTimeoutAcrossTransitions")(b("shield")(z), a - f))
    }

    function z(a, c) {
        a = Date.now();
        for (var c = c === !0 ? h.length - 1 : 0; c < h.length; c++) try {
            h[c]._frame(a) || h.splice(c--, 1)
        } catch (a) {
            h.splice(c--, 1)
        }
        h.length === 0 ? i && (g ? b("clearTimeout")(i) : b("clearInterval")(i), i = null) : g && g(z)
    }
    j.ease = {};
    j.ease.begin = function(a) {
        return Math.sin(Math.PI / 2 * (a - 1)) + 1
    };
    j.ease.end = function(a) {
        return Math.sin(.5 * Math.PI * a)
    };
    j.ease.both = function(a) {
        return .5 * Math.sin(Math.PI * (a - .5)) + .5
    };
    j.prependInsert = function(a, c) {
        j.insert(a, c, b("DOM").prependContent)
    };
    j.appendInsert = function(a, c) {
        j.insert(a, c, b("DOM").appendContent)
    };
    j.insert = function(a, c, d) {
        b("Style").set(c, "opacity", 0), d(a, c), new j(c).from("opacity", 0).to("opacity", 1).duration(400).go()
    };
    e.exports = j
}), null);
__d("BanzaiLogger", ["Banzai"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        return {
            log: function(b, d) {
                c("Banzai").post("logger:" + b, d, a)
            },
            create: h
        }
    }
    a = h();
    b = a;
    g["default"] = b
}), 98);