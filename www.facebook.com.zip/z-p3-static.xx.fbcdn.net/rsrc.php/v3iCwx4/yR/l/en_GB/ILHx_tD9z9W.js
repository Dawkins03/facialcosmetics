if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("PageHooks", ["Arbiter", "ErrorUtils", "InitialJSLoader", "PageEvents"], (function(a, b, c, d, e, f) {
    var g;
    f = {
        DOMREADY_HOOK: "domreadyhooks",
        ONLOAD_HOOK: "onloadhooks"
    };

    function h() {
        var c = a.CavalryLogger;
        !window.domready && c && c.getInstance().setTimeStamp("t_prehooks");
        k(l.DOMREADY_HOOK);
        !window.domready && c && c.getInstance().setTimeStamp("t_hooks");
        window.domready = !0;
        b("Arbiter").inform("uipage_onload", !0, "state")
    }

    function i() {
        k(l.ONLOAD_HOOK), window.loaded = !0
    }

    function j(a, c) {
        return (g || (g = b("ErrorUtils"))).applyWithGuard(a, null, null, function(a) {
            a.event_type = c, a.category = "runhook"
        }, "PageHooks:" + c)
    }

    function k(a) {
        var b = a == "onbeforeleavehooks" || a == "onbeforeunloadhooks";
        do {
            var c = window[a];
            if (!c) break;
            b || (window[a] = null);
            for (var d = 0; d < c.length; d++) {
                var e = j(c[d], a);
                if (b && e) return e
            }
        } while (!b && window[a])
    }

    function c() {
        window.domready || (window.domready = !0, k("onloadhooks")), window.loaded || (window.loaded = !0, k("onafterloadhooks"))
    }

    function d() {
        var a, c;
        (a = b("Arbiter")).registerCallback(h, [(c = b("PageEvents")).BIGPIPE_DOMREADY, b("InitialJSLoader").INITIAL_JS_READY]);
        a.registerCallback(i, [c.BIGPIPE_DOMREADY, c.BIGPIPE_ONLOAD, b("InitialJSLoader").INITIAL_JS_READY]);
        a.subscribe(c.NATIVE_ONBEFOREUNLOAD, function(a, b) {
            b.warn = k("onbeforeleavehooks") || k("onbeforeunloadhooks"), b.warn || (window.domready = !1, window.loaded = !1)
        }, "new");
        a.subscribe(c.NATIVE_ONUNLOAD, function(a, b) {
            k("onunloadhooks"), k("onafterunloadhooks")
        }, "new")
    }
    var l = babelHelpers["extends"]({
        _domreadyHook: h,
        _onloadHook: i,
        runHook: j,
        runHooks: k,
        keepWindowSetAsLoaded: c
    }, f);
    d();
    a.PageHooks = e.exports = l
}), null);
__d("XReferer", ["Base64", "Cookie", "FBJSON", "URI", "setTimeoutAcrossTransitions"], (function(a, b, c, d, e, f, g) {
    function a(a, b, d) {
        if (!d) {
            c("Cookie").set("x-referer", "");
            return
        }
        a != null && (a = i(a));
        b != null && (b = i(b));
        var e = window.location.pathname + window.location.search;
        d = c("URI").getRequestURI();
        var f = d.getSubdomain();
        b != null && h(b, e, f);
        a != null && c("setTimeoutAcrossTransitions")(function() {
            a != null && h(a, e, f)
        }, 0)
    }

    function h(a, b, e) {
        a = {
            r: a,
            h: b,
            s: e
        };
        b = c("Base64").encode(d("FBJSON").stringify(a));
        c("Cookie").set("x-referer", b)
    }

    function i(a) {
        var b = 1024;
        a && a.length > b && (a = a.substring(0, b) + "...");
        return a
    }
    g.update = a;
    g._setCookie = h;
    g.truncatePath = i
}), 98);
__d("goOrReplace", ["Env", "URI", "isFacebookURI"], (function(a, b, c, d, e, f, g) {
    function a(a, b, d) {
        b = new(c("URI"))(b);
        c("Env").isCQuick && c("isFacebookURI")(b) && b.addQueryData({
            cquick: c("Env").iframeKey,
            cquick_token: c("Env").iframeToken,
            ctarget: c("Env").iframeTarget
        });
        b = b.toString();
        d ? a.replace(b) : a.href == b ? a.reload() : a.href = b
    }
    g["default"] = a
}), 98);
__d("HistoryManager", ["Env", "Event", "SprinkleConfig", "URI", "UserAgent_DEPRECATED", "XReferer", "emptyFunction", "gkx", "goOrReplace", "isInIframe", "setIntervalAcrossTransitions"], (function(a, b, c, d, e, f) {
    var g, h, i = {
        history: null,
        current: 0,
        fragment: null,
        isInitialized: function() {
            return !!i._initialized
        },
        init: function() {
            if (!(g || (g = b("Env"))).ALLOW_TRANSITION_IN_IFRAME && b("isInIframe")()) return;
            if (i._initialized) return i;
            var a = new(h || (h = b("URI")))(window.location.href),
                c = a.getFragment() || "";
            c.charAt(0) === "!" && (c = c.substr(1), a.setFragment(c));
            Object.assign(i, {
                _initialized: !0,
                fragment: c,
                orig_fragment: c,
                history: [a],
                callbacks: [],
                lastChanged: Date.now(),
                canonical: new h("#"),
                user: 0,
                enabled: !0,
                debug: b("emptyFunction")
            });
            if (window.history && window.history.pushState) {
                this.lastURI = document.URL;
                c = new(h || (h = b("URI")))(this.lastURI);
                a = c.getQueryData();
                a.__md__ = void 0;
                a.__xts__ = void 0;
                a.fb_dtsg_ag = void 0;
                a[b("SprinkleConfig").param_name] = void 0;
                this.lastURI = c.setQueryData(a).toString();
                try {
                    window.history.state && b("gkx")("819236") ? window.history.replaceState(window.history.state, null, this.lastURI) : window.history.replaceState(this.lastURI, null, this.lastURI)
                } catch (a) {
                    if (!(a.number === -2147467259)) throw a
                }
                b("Event").listen(window, "popstate", function(a) {
                    var c = a && a.state && typeof a.state === "string";
                    c && i.lastURI != a.state && (i.lastURI = document.URL, i.lastChanged = Date.now(), i.notify(new(h || (h = b("URI")))(a.state).getUnqualifiedURI().toString()))
                });
                (b("UserAgent_DEPRECATED").webkit() < 534 || b("UserAgent_DEPRECATED").chrome() <= 13) && (b("setIntervalAcrossTransitions")(i.checkURI, 42), i._updateRefererURI(this.lastURI));
                return i
            }
            i._updateRefererURI(h.getRequestURI(!1));
            if (b("UserAgent_DEPRECATED").webkit() < 500 || b("UserAgent_DEPRECATED").firefox() < 2) {
                i.enabled = !1;
                return i
            }
            "onhashchange" in window ? b("Event").listen(window, "hashchange", function() {
                window.setTimeout(i.checkURI.bind(i), 0)
            }) : b("setIntervalAcrossTransitions")(i.checkURI, 42);
            return i
        },
        registerURIHandler: function(a) {
            i.callbacks.push(a);
            return i
        },
        setCanonicalLocation: function(a) {
            i.canonical = new(h || (h = b("URI")))(a);
            return i
        },
        notify: function(a) {
            a == i.orig_fragment && (a = i.canonical.getFragment());
            for (var b = 0; b < i.callbacks.length; b++) try {
                if (i.callbacks[b](a)) return !0
            } catch (a) {}
            return !1
        },
        checkURI: function() {
            if (Date.now() - i.lastChanged < 400) return;
            if (window.history && window.history.pushState) {
                var a = new(h || (h = b("URI")))(document.URL).removeQueryData("ref").toString(),
                    c = new h(i.lastURI).removeQueryData("ref").toString();
                a != c && (i.lastChanged = Date.now(), i.lastURI = a, b("UserAgent_DEPRECATED").webkit() < 534 && i._updateRefererURI(a), i.notify(new(h || (h = b("URI")))(a).getUnqualifiedURI().toString()));
                return
            }
            if (b("UserAgent_DEPRECATED").webkit() && window.history.length == 200) {
                i.warned || (i.warned = !0);
                return
            }
            c = new(h || (h = b("URI")))(window.location.href).getFragment();
            c.charAt(0) == "!" && (c = c.substr(1));
            c = c.replace(/%23/g, "#");
            if (c != i.fragment.replace(/%23/g, "#")) {
                i.debug([c, " vs ", i.fragment, "whl: ", window.history.length, "QHL: ", i.history.length].join(" "));
                for (var a = i.history.length - 1; a >= 0; --a)
                    if (i.history[a].getFragment().replace(/%23/g, "#") == c) break;
                ++i.user;
                a >= 0 ? i.go(a - i.current) : i.go("#" + c);
                --i.user
            }
        },
        _updateRefererURI: function(a) {
            a instanceof(h || (h = b("URI"))) && (a = a.toString()), b("XReferer").update(a, null, !0)
        },
        go: function(a, c, d) {
            if (window.history && window.history.pushState) {
                c || typeof a === "number";
                var e = new(h || (h = b("URI")))(a).removeQueryData(["ref", "messaging_source", "ajaxpipe_fetch_stream", "fb_dtsg_ag", b("SprinkleConfig").param_name]).toString();
                i.lastChanged = Date.now();
                this.lastURI = e;
                d ? window.history.replaceState(a, null, e) : window.history.pushState(a, null, e);
                b("UserAgent_DEPRECATED").webkit() < 534 && i._updateRefererURI(a);
                return !1
            }
            i.debug("go: " + a);
            c === void 0 && (c = !0);
            if (!i.enabled && !c) return !1;
            if (typeof a === "number") {
                if (!a) return !1;
                e = a + i.current;
                var f = Math.max(0, Math.min(i.history.length - 1, e));
                i.current = f;
                e = i.history[f].getFragment() || i.orig_fragment;
                e = new(h || (h = b("URI")))(e).removeQueryData("ref").getUnqualifiedURI().toString();
                i.fragment = e;
                i.lastChanged = Date.now();
                i.user || b("goOrReplace")(window.location, window.location.href.split("#")[0] + "#!" + e, d);
                c && i.notify(e);
                i._updateRefererURI(e);
                return !1
            }
            a = new(h || (h = b("URI")))(a);
            a.getDomain() == new(h || (h = b("URI")))(window.location.href).getDomain() && (a = new(h || (h = b("URI")))("#" + a.getUnqualifiedURI()));
            f = i.history[i.current].getFragment();
            e = a.getFragment();
            if (e == f || f == i.orig_fragment && e == i.canonical.getFragment()) {
                c && i.notify(e);
                i._updateRefererURI(e);
                return !1
            }
            d && i.current--;
            f = i.history.length - i.current - 1;
            i.history.splice(i.current + 1, f);
            i.history.push(new h(a));
            return i.go(1, c, d)
        },
        getCurrentFragment: function() {
            var a = (h || (h = b("URI"))).getRequestURI(!1).getFragment();
            return a == i.orig_fragment ? i.canonical.getFragment() : a
        }
    };
    e.exports = i
}), null);
__d("escapeJSQuotes", [], (function(a, b, c, d, e, f) {
    function a(a) {
        return typeof a === "undefined" || a == null || !a.valueOf() ? "" : a.toString().replace(/\\/g, "\\\\").replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\"/g, "\\x22").replace(/\'/g, "\\'").replace(/</g, "\\x3c").replace(/>/g, "\\x3e").replace(/&/g, "\\x26")
    }
    f["default"] = a
}), 66);
__d("PageTransitionsBlue", ["fbt", "invariant", "Arbiter", "BlueCompatBroker", "BlueCompatRouter", "Bootloader", "DOMQuery", "DOMScroll", "Env", "ErrorGuard", "Event", "FbtResultBase", "HistoryManager", "LayerHideOnEscape", "PageHooks", "PageTransitionsConfig", "PageTransitionsRegistrar", "ScriptPath", "URI", "Vector", "areEqual", "clickRefAction", "escapeJSQuotes", "ge", "gkx", "goOrReplace", "isFacebookURI", "isInIframe", "react", "setTimeout"], (function(a, b, c, d, e, f, g, h, i) {
    var j = d("react"),
        k = ["cquick", "ctarget", "cquick_token", "mh_", "killabyte", "tfc_", "tfi_"],
        l = {};

    function m(a, b) {
        a && (l[a.getUnqualifiedURI().toString()] = b)
    }

    function n(a) {
        return l[a.getUnqualifiedURI().toString()]
    }

    function o(a) {
        delete l[a.getUnqualifiedURI().toString()]
    }

    function p() {
        var a = {};
        window.location.search.slice(1).split("&").forEach(function(b) {
            b = b.split("=");
            var c = b[0];
            b = b[1];
            b = b === void 0 ? null : b;
            k.some(function(a) {
                return c.startsWith(a)
            }) && (a[c] = b)
        });
        return a
    }
    var q = null,
        r = !1,
        s = new(c("URI"))(""),
        t = null,
        u = new(c("URI"))(),
        v = null,
        w = !1,
        x = !1,
        y = !1,
        z = {
            isInitialized: function() {
                return r
            },
            init: function() {
                z._init()
            },
            _init: function() {
                if (c("isInIframe")()) return !1;
                if (r) return !0;
                var a = c("PageTransitionsRegistrar").getMostRecentURI();
                q = a;
                s = a;
                t = null;
                u = a;
                var b = c("ErrorGuard").applyWithGuard(function(a) {
                    return c("URI").tryParseURI(a)
                }, null, [document.referrer]);
                v = document.referrer && b && c("isFacebookURI")(b) ? b : null;
                r = !0;
                b = c("URI").getRequestURI(!1);
                b.getFragment().startsWith("/") ? b = b.getFragment() : b = a.toString();
                c("HistoryManager").init().setCanonicalLocation("#" + b).registerURIHandler(z._historyManagerHandler);
                c("Event").listen(window, "scroll", function() {
                    w || m(q, c("Vector").getScrollPosition())
                });
                return !0
            },
            registerHandler: c("PageTransitionsRegistrar").registerHandler,
            removeHandler: c("PageTransitionsRegistrar").removeHandler,
            getCurrentURI: function(a) {
                a === void 0 && (a = !1);
                z._init();
                return !q && !a ? new(c("URI"))(s) : new(c("URI"))(q)
            },
            isTransitioning: function() {
                z._init();
                return !q
            },
            getNextURI: function() {
                z._init();
                return u
            },
            getNextReferrerURI: function() {
                z._init();
                return t
            },
            getReferrerURI: function() {
                z._init();
                return v
            },
            getMostRecentURI: function() {
                z._init();
                return new(c("URI"))(s)
            },
            go: function(a, b) {
                b === void 0 && (b = !1);
                if (c("BlueCompatRouter").goFragment(a)) {
                    var d = new(c("URI"))(a);
                    if (z.restoreScrollPosition(d)) {
                        q = s = d;
                        return
                    }
                }
                if (c("BlueCompatRouter").go(a, b)) return;
                z.goBase(a, b)
            },
            goBase: function(a, b) {
                b === void 0 && (b = !1);
                z._init();
                var d = p(),
                    e = new(c("URI"))(a).removeQueryData("quickling").addQueryData(d).getQualifiedURI();
                o(e);
                b || c("clickRefAction")("uri", {
                    href: e.toString()
                }, null, "INDIRECT");
                z._loadPage(e, b, function(a) {
                    a ? c("HistoryManager").go(e.toString(), !1, b) : c("goOrReplace")(window.location, e, b)
                })
            },
            _historyManagerHandler: function(a) {
                if (a.charAt(0) != "/") return !1;
                c("clickRefAction")("h", {
                    href: a
                });
                d("ScriptPath").getClickPointInfo() || d("ScriptPath").setClickPointInfo({
                    click: "back"
                });
                z._loadPage(new(c("URI"))(a), !0, function(b) {
                    b || c("goOrReplace")(window.location, a, !0)
                });
                return !0
            },
            _loadPage: function(a, b, e) {
                if (new(c("URI"))(a).getFragment() && c("areEqual")(new(c("URI"))(a).setFragment("").getQualifiedURI(), new(c("URI"))(q).setFragment("").getQualifiedURI())) {
                    c("Arbiter").inform("pre_page_fragment_transition", {
                        from: new(c("URI"))(q).getFragment(),
                        to: new(c("URI"))(a).getFragment()
                    });
                    if (z.restoreScrollPosition(a)) {
                        q = s = a;
                        c("Arbiter").inform("page_fragment_transition", {
                            fragment: new(c("URI"))(a).getFragment()
                        });
                        return
                    }
                }
                var f;
                q && (f = n(q));
                var g = function() {
                        f && q && m(q, f);
                        t = z.getMostRecentURI();
                        q = null;
                        u = a;
                        f && d("DOMScroll").scrollTo(f, !1);
                        w = !0;
                        var g = z._handleTransition(a, b);
                        e && (g === c("PageTransitionsRegistrar").DELAY_HISTORY ? c("setTimeout")(function() {
                            return e && e(g)
                        }, 0) : e(g))
                    },
                    h = u;
                u = a;
                var i = c("PageHooks").runHooks("onbeforeleavehooks");
                u = h;
                i ? z._warnBeforeLeaving(i, g) : g()
            },
            _handleTransition: function(b, d) {
                window.onbeforeleavehooks = void 0;
                if (x || !b.isSameOrigin()) return !1;
                var e = c("PageTransitionsConfig").reloadOnBootloadError && z._hasBootloadErrors();
                if (e) return !1;
                var f;
                e = a.AsyncRequest;
                e && (f = e.getLastID());
                c("Arbiter").inform("pre_page_transition", {
                    from: z.getMostRecentURI(),
                    to: b
                });
                e = c("PageTransitionsRegistrar")._getTransitionHandlers();
                for (var g = e.length - 1; g >= 0; --g) {
                    var h = e[g];
                    if (!h) continue;
                    for (var i = h.length - 1; i >= 0; --i) {
                        var j = h[i](b, d);
                        if (j === !0 || j === c("PageTransitionsRegistrar").DELAY_HISTORY) {
                            var k = {
                                sender: z,
                                uri: b,
                                id: f
                            };
                            try {
                                c("Arbiter").inform("page_transition", k)
                            } catch (a) {}
                            return j
                        } else h.splice(i, 1)
                    }
                }
                return !1
            },
            disableTransitions: function() {
                x = !0
            },
            disableScrollAnimation: function() {
                y = !0
            },
            _hasBootloadErrors: function() {
                return c("Bootloader").getErrorCount() > 0
            },
            unifyURI: function() {
                z._init(), q = s = u, v = t
            },
            transitionComplete: function(a) {
                a === void 0 && (a = !1);
                z._init();
                w = !1;
                z._executeCompletionCallbacks();
                z.unifyURI();
                a || q && z.restoreScrollPosition(q);
                try {
                    document.activeElement && document.activeElement.nodeName === "A" && document.activeElement.blur()
                } catch (a) {}
            },
            _executeCompletionCallbacks: function() {
                var a = c("PageTransitionsRegistrar")._getCompletionCallbacks();
                a.length > 0 && (c("PageTransitionsRegistrar")._resetCompletionCallbacks(), a.forEach(function(a) {
                    return a()
                }))
            },
            registerCompletionCallback: c("PageTransitionsRegistrar").registerCompletionCallback,
            rewriteCurrentURI: function(a, b) {
                z._init();
                var d = c("PageTransitionsRegistrar")._getTransitionHandlers(),
                    e = d.length || 1,
                    f = !1;
                c("PageTransitionsRegistrar").registerHandler(function() {
                    if (a && a.toString() == z.getMostRecentURI().getUnqualifiedURI().toString()) {
                        z.transitionComplete();
                        return !0
                    }
                    f = !0
                }, e);
                z.go(b, !0);
                d.length === e + 1 && d[e].length === (f ? 0 : 1) || i(0, 1302);
                d.length = e
            },
            _warnBeforeLeaving: function(a, b) {
                c("Bootloader").loadModules(["DialogX", "XUIDialogTitle.react", "XUIDialogBody.react", "XUIDialogButton.react", "XUIDialogFooter.react", "XUIGrayText.react"], function(d, e, f, g, i, k) {
                    var l = typeof a === "string" || a instanceof String || a instanceof c("FbtResultBase") ? {
                        body: a,
                        highlightStay: !1,
                        leaveButtonText: h._( /*FBT_CALL*/ "Leave this Page" /*FBT_CALL*/ ),
                        showCloseButton: !1,
                        stayButtonText: h._( /*FBT_CALL*/ "Stay on This Page" /*FBT_CALL*/ ),
                        title: h._( /*FBT_CALL*/ "Leave page?" /*FBT_CALL*/ )
                    } : a;
                    e = j.jsx(e, {
                        showCloseButton: l.showCloseButton,
                        children: l.title
                    });
                    g = l.highlightStay ? [j.jsx(g, {
                        action: "confirm",
                        label: l.leaveButtonText
                    }, "confirm"), j.jsx(g, {
                        action: "cancel",
                        use: "confirm",
                        label: l.stayButtonText,
                        className: "autofocus"
                    }, "cancel")] : [j.jsx(g, {
                        action: "cancel",
                        label: l.stayButtonText
                    }, "cancel"), j.jsx(g, {
                        action: "confirm",
                        use: "confirm",
                        label: l.leaveButtonText,
                        className: "autofocus"
                    }, "confirm")];
                    var m = new d({
                        width: 450,
                        addedBehaviors: [c("LayerHideOnEscape")]
                    }, j.jsxs("div", {
                        children: [e, j.jsx(f, {
                            children: j.jsx(k, {
                                shade: "medium",
                                size: "medium",
                                children: l.body
                            })
                        }), j.jsx(i, {
                            children: g
                        })]
                    }));
                    m.subscribe("confirm", function() {
                        m.hide(), b()
                    });
                    m.show()
                }, "PageTransitionsBlue")
            },
            restoreScrollPosition: function(a) {
                var b = n(a);
                if (b) {
                    d("DOMScroll").scrollTo(b, !1);
                    return !0
                }

                function e(a) {
                    if (!a) return null;
                    var b = "a[name='" + c("escapeJSQuotes")(a) + "']";
                    return d("DOMQuery").scry(document.body, b)[0] || c("ge")(a)
                }
                b = e(new(c("URI"))(a).getFragment());
                if (b) {
                    e = !y;
                    d("DOMScroll").scrollTo(b, e);
                    return !0
                }
                return !1
            }
        };
    !c("gkx")("524") && c("Env").isCQuick && (d("BlueCompatBroker").init(), d("BlueCompatBroker").register("transitionpage", function(b) {
        b = new(c("URI"))(d("BlueCompatBroker").getMessageEventString(b, "uri"));
        var e = new(c("URI"))(window.location.href);
        b.removeQueryData("ctarget");
        e.removeQueryData("ctarget");
        if (e.toString() === b.toString()) return;
        e = a.AsyncRequest;
        e && e.ignoreUpdate();
        z.goBase(b, !1)
    }));
    b = z;
    a.PageTransitions = z;
    g["default"] = b
}), 98);