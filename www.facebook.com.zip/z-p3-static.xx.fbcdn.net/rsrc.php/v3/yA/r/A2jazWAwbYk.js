if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("Base64", [], (function(a, b, c, d, e, f) {
    var g = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

    function h(a) {
        a = a.charCodeAt(0) << 16 | a.charCodeAt(1) << 8 | a.charCodeAt(2);
        return String.fromCharCode(g.charCodeAt(a >>> 18), g.charCodeAt(a >>> 12 & 63), g.charCodeAt(a >>> 6 & 63), g.charCodeAt(a & 63))
    }
    var i = ">___?456789:;<=_______\0\x01\x02\x03\x04\x05\x06\x07\b\t\n\v\f\r\x0e\x0f\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19______\x1a\x1b\x1c\x1d\x1e\x1f !\"#$%&'()*+,-./0123";

    function j(a) {
        a = i.charCodeAt(a.charCodeAt(0) - 43) << 18 | i.charCodeAt(a.charCodeAt(1) - 43) << 12 | i.charCodeAt(a.charCodeAt(2) - 43) << 6 | i.charCodeAt(a.charCodeAt(3) - 43);
        return String.fromCharCode(a >>> 16, a >>> 8 & 255, a & 255)
    }
    var k = {
        encode: function(a) {
            a = unescape(encodeURI(a));
            var b = (a.length + 2) % 3;
            a = (a + "\0\0".slice(b)).replace(/[\s\S]{3}/g, h);
            return a.slice(0, a.length + b - 2) + "==".slice(b)
        },
        decode: function(a) {
            a = a.replace(/[^A-Za-z0-9+\/]/g, "");
            var b = a.length + 3 & 3;
            a = (a + "AAA".slice(b)).replace(/..../g, j);
            a = a.slice(0, a.length + b - 3);
            try {
                return decodeURIComponent(escape(a))
            } catch (a) {
                throw new Error("Not valid UTF-8")
            }
        },
        encodeObject: function(a) {
            return k.encode(JSON.stringify(a))
        },
        decodeObject: function(a) {
            return JSON.parse(k.decode(a))
        },
        encodeNums: function(a) {
            return String.fromCharCode.apply(String, a.map(function(a) {
                return g.charCodeAt((a | -(a > 63 ? 1 : 0)) & -(a > 0 ? 1 : 0) & 63)
            }))
        }
    };
    a = k;
    f["default"] = a
}), 66);
__d("Deferred", ["Promise"], (function(a, b, c, d, e, f) {
    "use strict";
    b("Promise").resolve();
    a = function() {
        function a(a) {
            var c = this;
            a = a || b("Promise");
            this.$1 = !1;
            this.$2 = new a(function(a, b) {
                c.$3 = a, c.$4 = b
            })
        }
        var c = a.prototype;
        c.getPromise = function() {
            return this.$2
        };
        c.resolve = function(a) {
            this.$1 = !0, this.$3(a)
        };
        c.reject = function(a) {
            this.$1 = !0, this.$4(a)
        };
        c.isSettled = function() {
            return this.$1
        };
        return a
    }();
    f["default"] = a
}), 66);
__d("UserActivity", ["cr:1634616"], (function(a, b, c, d, e, f) {
    e.exports = b("cr:1634616")
}), null);
__d("UserActivityBlue", ["Arbiter", "Event", "isTruthy"], (function(a, b, c, d, e, f) {
    var g = 5e3,
        h = 500,
        i = -5,
        j = Date.now(),
        k = j,
        l = !1,
        m = Date.now(),
        n = document.hasFocus ? document.hasFocus() : !0,
        o = 0,
        p = Date.now(),
        q = -1,
        r = -1,
        s = !1,
        t = !1,
        u = {
            EVENT_INTERVAL_MS: h,
            subscribeOnce: function(a) {
                var b = u.subscribe(function(c, d) {
                    u.unsubscribe(b), a(d)
                });
                return b
            },
            subscribe: function(a) {
                return b("Arbiter").subscribe("useractivity/activity", a)
            },
            unsubscribe: function(a) {
                a.unsubscribe()
            },
            isActive: function(a) {
                return new Date() - j < (b("isTruthy")(a) ? a : g)
            },
            isOnTab: function() {
                return n
            },
            hasBeenInactive: function() {
                return l
            },
            resetActiveStatus: function() {
                n = !0, l = !1
            },
            getLastInActiveEnds: function() {
                return m
            },
            getLastActive: function() {
                return j
            },
            setIdleTime: function(a) {
                o = a
            },
            getLastLeaveTime: function() {
                return p
            },
            getLastInformTime: function() {
                return k
            },
            hasClicked: function() {
                return s
            },
            hasInteractedWithKeyboard: function() {
                return t
            },
            reset: function() {
                j = Date.now(), k = j, l = !1, m = Date.now(), n = document.hasFocus ? document.hasFocus() : !0, o = 0, p = Date.now(), q = -1, r = -1, s = !1, t = !1
            }
        };

    function v(a) {
        x(a, h)
    }

    function w(a) {
        x(a, 0)
    }

    function x(c, d) {
        d === void 0 && (d = 0);
        var e = a.KeyboardEvent,
            f = a.MouseEvent;
        if (f && c instanceof f) {
            if (/^mouse(enter|leave|move|out|over)$/.test(c.type) && c.pageX == q && c.pageY == r) return;
            q = c.pageX;
            r = c.pageY
        } else e && c instanceof e && (t = !0);
        (c.type === "click" || c.type === "dblclick" || c.type === "contextmenu") && (s = !0);
        j = Date.now();
        f = j - k;
        f > d ? (k = j, n || (p = j), f >= (o || g) && (l = !0, m = j), b("Arbiter").inform("useractivity/activity", {
            event: c,
            idleness: f,
            last_inform: k
        })) : f < i && (k = j)
    }

    function c(a) {
        n = !0, m = Date.now(), w(a)
    }

    function d(a) {
        n = !1, l = !0, p = Date.now()
    }
    b("Event").listen(window, "scroll", v);
    b("Event").listen(window, "focus", c);
    b("Event").listen(window, "blur", d);
    b("Event").listen(document.documentElement, {
        keydown: v,
        mouseover: v,
        mousemove: v,
        click: v
    }, void 0, void 0, {
        passive: !0
    });
    b("Arbiter").subscribe("Event/stop", function(a, b) {
        v(b.event)
    });
    e.exports = u
}), null);