if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("DOMControl", ["$", "DataStore"], (function(a, b, c, d, e, f) {
    a = function() {
        "use strict";

        function a(a) {
            this.root = b("$").fromIDOrElement(a), this.updating = !1, b("DataStore").set(a, "DOMControl", this)
        }
        var c = a.prototype;
        c.getRoot = function() {
            return this.root
        };
        c.beginUpdate = function() {
            if (this.updating) return !1;
            this.updating = !0;
            return !0
        };
        c.endUpdate = function() {
            this.updating = !1
        };
        c.update = function(a) {
            if (!this.beginUpdate()) return this;
            this.onupdate(a);
            this.endUpdate()
        };
        c.onupdate = function(a) {};
        a.getInstance = function(a) {
            return b("DataStore").get(a, "DOMControl")
        };
        return a
    }();
    e.exports = a
}), null);
__d("DOMScroll", ["Arbiter", "DOM", "DOMQuery", "Vector", "ViewportBounds", "emptyFunction", "ge", "isAsyncScrollQuery", "nullthrows", "requireDeferred"], (function(a, b, c, d, e, f) {
    var g = b("requireDeferred")("Animation").__setRef("DOMScroll"),
        h = {
            SCROLL: "dom-scroll",
            _scrolling: !1,
            _scrollingFinishedTimeout: null,
            getScrollState: function() {
                var a = b("Vector").getViewportDimensions(),
                    c = b("Vector").getDocumentDimensions(),
                    d = c.x > a.x;
                c = c.y > a.y;
                d += 0;
                c += 0;
                return new(b("Vector"))(d, c)
            },
            _scrollbarSize: null,
            _initScrollbarSize: function() {
                var a = b("DOM").create("p");
                a.style.width = "100%";
                a.style.height = "200px";
                var c = b("DOM").create("div");
                c.style.position = "absolute";
                c.style.top = "0px";
                c.style.left = "0px";
                c.style.visibility = "hidden";
                c.style.width = "200px";
                c.style.height = "150px";
                c.style.overflow = "hidden";
                c.appendChild(a);
                b("nullthrows")(document.body).appendChild(c);
                var d = a.offsetWidth;
                c.style.overflow = "scroll";
                a = a.offsetWidth;
                d == a && (a = c.clientWidth);
                b("nullthrows")(document.body).removeChild(c);
                h._scrollbarSize = d - a
            },
            getScrollbarSize: function() {
                h._scrollbarSize === null && h._initScrollbarSize();
                return b("nullthrows")(h._scrollbarSize)
            },
            scrollTo: function(a, c, d, e, f, i) {
                var j, k = 0;
                c == null || c === !0 ? k = 750 : typeof c === "number" ? k = c : parseInt(c, 10) && (k = parseInt(c, 10));
                b("isAsyncScrollQuery")() && (k = 0);
                if (a instanceof b("Vector")) c = a;
                else {
                    var l = b("Vector").getScrollPosition().x;
                    a = b("Vector").getElementPosition(b("ge")(a)).y;
                    c = new(b("Vector"))(l, a, "document");
                    e || (c.y -= b("ViewportBounds").getTop() / (d ? 2 : 1))
                }
                d ? c.y -= b("Vector").getViewportDimensions().y / 2 : e && (c.y -= b("Vector").getViewportDimensions().y, c.y += e);
                f && (c.y -= f);
                c = c.convertTo("document");
                if (k)
                    if ("scrollBehavior" in b("nullthrows")(document.documentElement).style && k === 750 && !i) try {
                        window.scrollTo({
                            left: c.x,
                            top: c.y,
                            behavior: "smooth"
                        })
                    } catch (a) {
                        window.scrollTo(c.x, c.y)
                    } else {
                        l = g.getModuleIfRequired();
                        if (l != null) {
                            h._setScrollingForDuration(k);
                            var m = new l(b("nullthrows")(document.body)).to("scrollTop", c.y).to("scrollLeft", c.x).ease(l.ease.end).duration(k).ondone(i).go();
                            j = function() {
                                m.stop()
                            }
                        } else window.scrollTo(c.x, c.y), i && i()
                    } else window.scrollTo(c.x, c.y), i && i();
                b("Arbiter").inform(h.SCROLL);
                return j || b("emptyFunction")
            },
            scrollToID: function(a) {
                h.scrollTo(a)
            },
            ensureVisible: function(a, c, d, e, f) {
                var g = b("Vector").getScrollPosition().x;
                a = h._getBounds(a, c, d);
                c = a[0];
                d = a[1];
                var i = a[2];
                a = a[3];
                i < c ? h.scrollTo(new(b("Vector"))(g, i, "document"), e, !1, 0, 0, f) : a > d ? i - (a - d) < c ? h.scrollTo(new(b("Vector"))(g, i, "document"), e, !1, 0, 0, f) : h.scrollTo(new(b("Vector"))(g, a, "document"), e, !1, 1, 0, f) : f && f()
            },
            isCurrentlyVisible: function(a, b, c) {
                a = h._getBounds(a, b, c);
                b = a[0];
                c = a[1];
                var d = a[2];
                a = a[3];
                return d >= b && a <= c
            },
            _getBounds: function(a, c, d) {
                d == null && (d = 10);
                a = b("ge")(a);
                c && (a = b("DOMQuery").find(a, c));
                c = b("Vector").getScrollPosition().y;
                var e = c + b("Vector").getViewportDimensions().y,
                    f = b("Vector").getElementPosition(a).y;
                a = f + b("Vector").getElementDimensions(a).y;
                f -= b("ViewportBounds").getTop();
                f -= d;
                a += d;
                return [c, e, f, a]
            },
            scrollToTop: function(a) {
                var c = b("Vector").getScrollPosition();
                h.scrollTo(new(b("Vector"))(c.x, 0, "document"), a !== !1)
            },
            currentlyScrolling: function() {
                return h._scrolling
            },
            _setScrollingForDuration: function(a) {
                h._scrolling = !0, h._scrollingFinishedTimeout && (clearTimeout(h._scrollingFinishedTimeout), h._scrollingFinishedTimeout = null), h._scrollingFinishedTimeout = setTimeout(function() {
                    h._scrolling = !1, h._scrollingFinishedTimeout = null
                }, a)
            }
        };
    e.exports = h
}), null);
__d("Input", ["CSS", "DOMControl", "DOMQuery"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        return !/\S/.test(a || "")
    }

    function i(a) {
        return h(a.value)
    }

    function a(a) {
        return i(a) ? "" : a.value
    }

    function b(a) {
        return a.value
    }

    function e(a, b) {
        a.value = b || "";
        b = c("DOMControl").getInstance(a);
        b && b.resetHeight && b.resetHeight()
    }

    function f(a, b) {
        b || (b = ""), a.setAttribute("aria-label", b), a.setAttribute("placeholder", b)
    }

    function j(a) {
        a.value = "", a.style.height = ""
    }

    function k(a, b) {
        d("CSS").conditionClass(a, "enter_submit", b)
    }

    function l(a) {
        return d("CSS").hasClass(a, "enter_submit")
    }

    function m(a, b) {
        b > 0 ? a.setAttribute("maxlength", b.toString()) : a.removeAttribute("maxlength")
    }
    g.isWhiteSpaceOnly = h;
    g.isEmpty = i;
    g.getValue = a;
    g.getValueRaw = b;
    g.setValue = e;
    g.setPlaceholder = f;
    g.reset = j;
    g.setSubmitOnEnter = k;
    g.getSubmitOnEnter = l;
    g.setMaxLength = m
}), 98);
__d("Form", ["DOM", "DOMQuery", "DTSG", "DTSGUtils", "DataStore", "Input", "LSD", "PHPQuerySerializer", "Random", "SprinkleConfig", "URI", "getElementPosition", "isFacebookURI", "isNode"], (function(a, b, c, d, e, f) {
    var g, h, i = "FileList" in window,
        j = "FormData" in window;

    function k(a) {
        var c = {};
        (g || (g = b("PHPQuerySerializer"))).serialize(a).split("&").forEach(function(a) {
            if (a) {
                a = /^([^=]*)(?:=(.*))?$/.exec(a);
                var d = (h || (h = b("URI"))).decodeComponent(a[1]),
                    e = a[2] !== void 0;
                e = e ? (h || (h = b("URI"))).decodeComponent(a[2]) : null;
                c[d] = e
            }
        });
        return c
    }
    var l = {
        getInputs: function(a) {
            a === void 0 && (a = document);
            return [].concat(b("DOMQuery").scry(a, "input"), b("DOMQuery").scry(a, "select"), b("DOMQuery").scry(a, "textarea"), b("DOMQuery").scry(a, "button"))
        },
        getInputsByName: function(a) {
            var b = {};
            l.getInputs(a).forEach(function(a) {
                var c = b[a.name];
                b[a.name] = typeof c === "undefined" ? a : [a].concat(c)
            });
            return b
        },
        getSelectValue: function(a) {
            return a.options[a.selectedIndex].value
        },
        setSelectValue: function(a, b) {
            for (var c = 0; c < a.options.length; ++c)
                if (a.options[c].value == b) {
                    a.selectedIndex = c;
                    break
                }
        },
        getRadioValue: function(a) {
            for (var b = 0; b < a.length; b++)
                if (a[b].checked) return a[b].value;
            return null
        },
        getElements: function(a) {
            return a.tagName == "FORM" && a.elements != a ? Array.from(a.elements) : l.getInputs(a)
        },
        getAttribute: function(a, b) {
            return (a.getAttributeNode(b) || {}).value || null
        },
        setDisabled: function(a, c) {
            l.getElements(a).forEach(function(a) {
                if (a.disabled !== void 0) {
                    var d = b("DataStore").get(a, "origDisabledState");
                    c ? (d === void 0 && b("DataStore").set(a, "origDisabledState", a.disabled), a.disabled = c) : d === !1 && (a.disabled = !1)
                }
            })
        },
        forEachValue: function(a, c, d) {
            l.getElements(a).forEach(function(a) {
                if (!a.name || a.disabled) return;
                if (a.type === "submit") return;
                if (a.type === "reset" || a.type === "button" || a.type === "image") return;
                if ((a.type === "radio" || a.type === "checkbox") && !a.checked) return;
                if (a.nodeName === "SELECT") {
                    for (var c = 0, e = a.options.length; c < e; c++) {
                        var f = a.options[c];
                        f.selected && d("select", a.name, f.value)
                    }
                    return
                }
                if (a.type === "file") {
                    if (i) {
                        f = a.files;
                        for (var c = 0; c < f.length; c++) d("file", a.name, f.item(c))
                    }
                    return
                }
                d(a.type, a.name, b("Input").getValue(a))
            }), c && c.name && c.type === "submit" && b("DOMQuery").contains(a, c) && b("DOMQuery").isNodeOfType(c, ["input", "button"]) && d("submit", c.name, c.value)
        },
        createFormData: function(a, c) {
            if (!j) return null;
            var d = new FormData();
            if (a)
                if (b("isNode")(a)) l.forEachValue(a, c, function(a, b, c) {
                    d.append(b, c)
                });
                else {
                    c = k(a);
                    for (var a in c) c[a] == null ? d.append(a, "") : d.append(a, c[a])
                }
            return d
        },
        serialize: function(a, b) {
            var c = {};
            l.forEachValue(a, b, function(a, b, d) {
                if (a === "file") return;
                l._serializeHelper(c, b, d)
            });
            return l._serializeFix(c)
        },
        _serializeHelper: function(a, b, c) {
            var d = Object.prototype.hasOwnProperty,
                e = /([^\]]+)\[([^\]]*)\](.*)/.exec(b);
            if (e) {
                if (!a[e[1]] || !d.call(a, e[1])) {
                    a[e[1]] = d = {};
                    if (a[e[1]] !== d) return
                }
                d = 0;
                if (e[2] === "")
                    while (a[e[1]][d] !== void 0) d++;
                else d = e[2];
                e[3] === "" ? a[e[1]][d] = c : l._serializeHelper(a[e[1]], d.concat(e[3]), c)
            } else a[b] = c
        },
        _serializeFix: function(a) {
            for (var b in a) a[b] instanceof Object && (a[b] = l._serializeFix(a[b]));
            b = Object.keys(a);
            if (b.length === 0 || b.some(isNaN)) return a;
            b.sort(function(a, b) {
                return a - b
            });
            var c = 0,
                d = b.every(function(a) {
                    return +a === c++
                });
            return d ? b.map(function(b) {
                return a[b]
            }) : a
        },
        post: function(a, c, d, e) {
            e === void 0 && (e = !0);
            a = new(h || (h = b("URI")))(a);
            var f = document.createElement("form");
            f.action = a.toString();
            f.method = "POST";
            f.style.display = "none";
            var g = !b("isFacebookURI")(a);
            if (d) {
                if (g) {
                    f.rel = "noopener";
                    if (d === "_blank") {
                        d = btoa(b("Random").uint32());
                        var i = window.open("about:blank", d);
                        i === void 0 || (i.opener = null)
                    }
                }
                f.target = d
            }
            if (e && (!g && a.getSubdomain() !== "apps")) {
                i = b("DTSG").getToken();
                i && (c.fb_dtsg = i, b("SprinkleConfig").param_name && (c[b("SprinkleConfig").param_name] = b("DTSGUtils").getNumericValue(i)));
                b("LSD").token && (c.lsd = b("LSD").token, b("SprinkleConfig").param_name && !i && (c[b("SprinkleConfig").param_name] = b("DTSGUtils").getNumericValue(b("LSD").token)))
            }
            l.createHiddenInputs(c, f);
            b("DOMQuery").getRootElement().appendChild(f);
            f.submit();
            return !1
        },
        createHiddenInputs: function(a, c, d, e) {
            e === void 0 && (e = !1);
            d = d || {};
            a = k(a);
            for (var f in a) {
                if (a[f] === null) continue;
                if (d[f] && e) d[f].value = a[f];
                else {
                    var g = b("DOM").create("input", {
                        type: "hidden",
                        name: f,
                        value: a[f]
                    });
                    d[f] = g;
                    c.appendChild(g)
                }
            }
            return d
        },
        getFirstElement: function(a, c) {
            c === void 0 && (c = ['input[type="text"]', "textarea", 'input[type="password"]', 'input[type="button"]', 'input[type="submit"]']);
            var d = [];
            for (var e = 0; e < c.length; e++) {
                d = b("DOMQuery").scry(a, c[e]);
                for (var f = 0; f < d.length; f++) {
                    var g = d[f];
                    try {
                        var h = b("getElementPosition")(g);
                        if (h.y > 0 && h.x > 0) return g
                    } catch (a) {}
                }
            }
            return null
        },
        focusFirst: function(a) {
            a = l.getFirstElement(a);
            if (a) {
                a.focus();
                return !0
            }
            return !1
        }
    };
    e.exports = l
}), null);
__d("LinkController", ["DataStore", "Event", "Parent", "removeFromArray", "trackReferrer"], (function(a, b, c, d, e, f, g) {
    var h = "@@LinkController",
        i = [],
        j = [];

    function a(a) {
        i.push(a);
        return {
            remove: function() {
                return c("removeFromArray")(i, a)
            }
        }
    }

    function b(a) {
        j.push(a);
        return {
            remove: function() {
                return c("removeFromArray")(j, a)
            }
        }
    }

    function e(a) {
        a = a.getTarget();
        var b = d("Parent").byTag(a, "a");
        if (!(b instanceof HTMLAnchorElement)) return;
        var e = l(b);
        if (e == null || e.trim() === "" || n(a) || d("DataStore").get(b, h) || e.endsWith("#")) return;
        a = c("Event").listen(b, "click", function(a) {
            c("trackReferrer")(b, e), !b.rel && (!b.target || b.target === "_self") && !m(a) && k(b, a)
        });
        d("DataStore").set(b, h, a)
    }

    function k(a, b) {
        i.concat(j).every(function(c) {
            if (c(a, b) === !1) {
                b.prevent();
                return !1
            }
            return !0
        })
    }

    function l(a) {
        if (a && !a.rel) {
            a = a.getAttribute("href");
            if (a != null) {
                var b = a.match(/^(\w+):/);
                if (!b || b[1].match(/^http/i)) return a
            }
        }
        return null
    }

    function m(a) {
        return a.getModifiers().any || a.which != null && a.which !== 1
    }

    function n(a) {
        return a.nodeName === "INPUT" && a.type === "file"
    }
    c("Event").listen(document.documentElement, "mousedown", e, c("Event").Priority.URGENT);
    c("Event").listen(document.documentElement, "keydown", e, c("Event").Priority.URGENT);
    g.registerHandler = a;
    g.registerFallbackHandler = b
}), 98);
__d("PageTransitionPriorities", [], (function(a, b, c, d, e, f) {
    a = 5;
    b = a + 1;
    c = b + 1;
    f.DEFAULT = a;
    f.LEFT_NAV = b;
    f.SOCIAL_SEARCH_DIALOG = c
}), 66);
__d("computeRelativeURI", ["URI", "isEmpty", "isFacebookURI"], (function(a, b, c, d, e, f, g) {
    function h(a, b) {
        if (!b) return a;
        if (b.charAt(0) == "/") return b;
        var c = a.split("/").slice(0, -1);
        c[0] !== "";
        b.split("/").forEach(function(a) {
            a === "." || (a === ".." ? c.length > 1 && (c = c.slice(0, -1)) : c.push(a))
        });
        return c.join("/")
    }

    function a(a, b) {
        var d = new(c("URI"))(),
            e = new(c("URI"))(a),
            f = new(c("URI"))(b);
        if (f.getDomain() && !c("isFacebookURI")(f)) return b;
        var g = e;
        a = ["Protocol", "Domain", "Port", "Path", "QueryData", "Fragment"];
        a.forEach(function(a) {
            var b = a === "Path" && g === e;
            b && d.setPath(h(e.getPath(), f.getPath()));
            c("isEmpty")(f["get" + a]()) || (g = f);
            b || d["set" + a](g["get" + a]())
        });
        return d
    }
    g["default"] = a
}), 98);
__d("PageTransitionsRegistrar", ["invariant", "DOMQuery", "Form", "LinkController", "PageTransitionPriorities", "Parent", "URI", "computeRelativeURI", "getReferrerURI", "goURI", "requireDeferred", "setTimeout", "setTimeoutAcrossTransitions"], (function(a, b, c, d, e, f, g, h) {
    var i = c("requireDeferred")("PageTransitions").__setRef("PageTransitionsRegistrar");
    c("setTimeout")(function() {
        i.onReady(function(a) {
            a && a._init && a._init()
        })
    }, 0);
    var j = [],
        k = [];
    e = {
        DELAY_HISTORY: "delay_history_PTR",
        registerHandler: function(a, b) {
            a != null || h(0, 5202), b = b || d("PageTransitionPriorities").DEFAULT, j[b] || (j[b] = []), j[b].push(a)
        },
        removeHandler: function(a, b) {
            b = b || d("PageTransitionPriorities").DEFAULT;
            var c = -1;
            j[b] && (c = j[b].indexOf(a));
            c > -1 && j[b].splice(c, 1)
        },
        registerCompletionCallback: function(a) {
            k.push(a)
        },
        getMostRecentURI: n,
        getReferrerURI: c("getReferrerURI"),
        _getTransitionHandlers: function() {
            return j
        },
        _getCompletionCallbacks: function() {
            return k
        },
        _resetCompletionCallbacks: function() {
            k = []
        },
        __onClick: e,
        __onSubmit: f
    };
    var l = null;

    function b(a) {
        l = a, c("setTimeoutAcrossTransitions")(function() {
            l = null
        }, 0)
    }

    function e(a) {
        if (l) {
            if (!a.isDefaultPrevented()) {
                m(l);
                var b = l.getAttribute("href");
                b && c("goURI")(b)
            }
            a.kill()
        }
    }

    function m(a) {
        var b = a.getAttribute("href") || "",
            d = c("computeRelativeURI")(n().getQualifiedURI().toString(), b).toString();
        b != d && a.setAttribute("href", d)
    }

    function f(a, b) {
        b = b;
        var e = a.getTarget();
        if (d("Form").getAttribute(e, "rel") || d("Form").getAttribute(e, "target")) return;
        var f = new(c("URI"))(d("Form").getAttribute(e, "action"));
        f = c("computeRelativeURI")(n().toString(), f.toString());
        e.setAttribute("action", f.toString());
        if ((d("Form").getAttribute(e, "method") || "GET").toUpperCase() == "GET") {
            e = d("Form").serialize(e);
            b && (d("DOMQuery").isNodeOfType(b, "input") && b.type === "submit" || (b = d("Parent").byTag(b, "button"))) && b.name && (e[b.name] = b.value);
            typeof f === "string" && (f = new(c("URI"))(f));
            c("goURI")(f.addQueryData(e));
            a.kill()
        }
    }
    d("LinkController").registerFallbackHandler(b);

    function n() {
        if (a.PageTransitions && a.PageTransitions.isInitialized()) return a.PageTransitions.getMostRecentURI();
        else {
            var b = c("URI").getRequestURI(!1);
            b = b.getUnqualifiedURI();
            var d = new(c("URI"))(b).setFragment(""),
                e = b.getFragment();
            e.charAt(0) === "!" && d.toString() === e.substr(1) && (b = d);
            return b
        }
    }
    f = e;
    g["default"] = f
}), 98);
__d("LayerHideSources", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        BLUR: "blur",
        ESCAPE: "escape",
        LAYER_CANCEL_BUTTON: "layerCancelButton",
        LAYER_HIDE_BUTTON: "layerHideButton",
        TRANSITION: "transition"
    });
    b = a;
    f["default"] = b
}), 66);
__d("LayerHideOnEscape", ["Event", "Keys", "LayerHideSources"], (function(a, b, c, d, e, f, g) {
    a = function() {
        function a(a) {
            this._layer = a
        }
        var b = a.prototype;
        b.enable = function() {
            this._subscription = this._layer.subscribe("key", this.handle.bind(this))
        };
        b.disable = function() {
            this._subscription != null && this._subscription.unsubscribe(), this._subscription = null
        };
        b.handle = function(a, b) {
            if (c("Event").getKeyCode(b) === c("Keys").ESC) {
                this._layer.hide(c("LayerHideSources").ESCAPE);
                return !1
            }
            return void 0
        };
        return a
    }();
    Object.assign(a.prototype, {
        _subscription: null
    });
    g["default"] = a
}), 98);
__d("LayerHideOnTransition", ["LayerHideSources", "PageTransitionsRegistrar"], (function(a, b, c, d, e, f, g) {
    a = function() {
        function a(a) {
            var b = this;
            this._handler = function(a) {
                b._enabled && b.isTransitionRelevant(a) && b._layer.hide(c("LayerHideSources").TRANSITION), b._subscribe()
            };
            this._layer = a
        }
        var b = a.prototype;
        b.enable = function() {
            this._enabled = !0, this._subscribed || setTimeout(this._subscribe.bind(this), 0)
        };
        b.disable = function() {
            this._enabled = !1, c("PageTransitionsRegistrar").removeHandler(this._handler)
        };
        b.isTransitionRelevant = function(a) {
            return !0
        };
        b._subscribe = function() {
            c("PageTransitionsRegistrar").registerHandler(this._handler), this._subscribed = !0
        };
        return a
    }();
    Object.assign(a.prototype, {
        _enabled: !1,
        _subscribed: !1
    });
    g["default"] = a
}), 98);