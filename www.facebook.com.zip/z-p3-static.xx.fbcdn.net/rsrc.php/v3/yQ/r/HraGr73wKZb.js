if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("ContextualLayerAlignmentEnum", ["keyMirror", "objectValues", "prop-types"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("keyMirror")({
        left: null,
        center: null,
        right: null
    });
    b = c("objectValues")(a);
    d = c("prop-types").oneOf(b);
    e = babelHelpers["extends"]({}, a, {
        values: b,
        propType: d
    });
    g["default"] = e
}), 98);
__d("ContextualLayerPositionEnum", ["keyMirror", "objectValues", "prop-types"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = c("keyMirror")({
        above: null,
        below: null,
        left: null,
        right: null
    });
    b = c("objectValues")(a);
    d = c("prop-types").oneOf(b);
    e = babelHelpers["extends"]({}, a, {
        values: b,
        propType: d
    });
    g["default"] = e
}), 98);
__d("NavigationMessage", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        NAVIGATION_BEGIN: "NavigationMessage/navigationBegin",
        NAVIGATION_SELECT: "NavigationMessage/navigationSelect",
        NAVIGATION_FIRST_RESPONSE: "NavigationMessage/navigationFirstResponse",
        NAVIGATION_COMPLETED: "NavigationMessage/navigationCompleted",
        NAVIGATION_FAILED: "NavigationMessage/navigationFailed",
        NAVIGATION_COUNT_UPDATE: "NavigationMessage/navigationCount",
        NAVIGATION_FAVORITE_UPDATE: "NavigationMessage/navigationFavoriteUpdate",
        NAVIGATION_ITEM_REMOVED: "NavigationMessage/navigationItemRemoved",
        NAVIGATION_ITEM_HIDDEN: "NavigationMessage/navigationItemHidden",
        INTERNAL_LOADING_BEGIN: "NavigationMessage/internalLoadingBegin",
        INTERNAL_LOADING_COMPLETED: "NavigationMessage/internalLoadingCompleted"
    });
    f["default"] = a
}), 66);
__d("XBasicFBNuxDismissController", ["XController"], (function(a, b, c, d, e, f) {
    e.exports = b("XController").create("/ajax/megaphone/dismiss_fbnux/", {
        nux_id: {
            type: "Int",
            required: !0
        }
    })
}), null);
__d("XBasicFBNuxViewController", ["XController"], (function(a, b, c, d, e, f) {
    e.exports = b("XController").create("/ajax/megaphone/view_fbnux/", {
        nux_id: {
            type: "Int",
            required: !0
        }
    })
}), null);
__d("BasicFBNux", ["AsyncRequest", "XBasicFBNuxDismissController", "XBasicFBNuxViewController"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        a.subscribe("hide", function() {
            return h(b)
        })
    }

    function b(a) {
        a = c("XBasicFBNuxViewController").getURIBuilder().setInt("nux_id", a).getURI();
        new(c("AsyncRequest"))().setURI(a).send()
    }

    function h(a) {
        a = c("XBasicFBNuxDismissController").getURIBuilder().setInt("nux_id", a).getURI();
        new(c("AsyncRequest"))().setURI(a).send()
    }
    g.subscribeHide = a;
    g.onView = b;
    g.onDismiss = h
}), 98);
__d("ARIA", ["DOM", "emptyFunction", "ge", "getOrCreateDOMID", "joinClasses"], (function(a, b, c, d, e, f, g) {
    var h, i, j = function() {
        h = c("ge")("ariaAssertiveAlert"), h || (h = c("DOM").create("div", {
            id: "ariaAssertiveAlert",
            className: c("joinClasses")("accessible_elem", "accessible_elem_offset"),
            "aria-live": "assertive"
        }), c("DOM").appendContent(document.body, h)), i = c("ge")("ariaPoliteAlert"), i || (i = h.cloneNode(!1), i.setAttribute("id", "ariaPoliteAlert"), i.setAttribute("aria-live", "polite"), c("DOM").appendContent(document.body, i)), j = c("emptyFunction")
    };

    function k(a, b) {
        j();
        b = b ? h : i;
        c("DOM").setContent(b, a)
    }

    function a(a) {
        for (var b = arguments.length, d = new Array(b > 1 ? b - 1 : 0), e = 1; e < b; e++) d[e - 1] = arguments[e];
        var f = d.map(function(a) {
            return c("getOrCreateDOMID")(a)
        }).join(" ");
        a.setAttribute("aria-controls", f)
    }

    function b(a) {
        for (var b = arguments.length, d = new Array(b > 1 ? b - 1 : 0), e = 1; e < b; e++) d[e - 1] = arguments[e];
        var f = d.map(function(a) {
            return c("getOrCreateDOMID")(a)
        }).join(" ");
        a.setAttribute("aria-describedby", f)
    }

    function d(a, b) {
        a.setAttribute("aria-owns", c("getOrCreateDOMID")(b))
    }

    function e(a, b) {
        b = c("getOrCreateDOMID")(b);
        a.setAttribute("aria-controls", b);
        a.setAttribute("aria-haspopup", "true");
        b = a.getAttribute("role") || "";
        b && a.setAttribute("role", b)
    }

    function f(a) {
        k(a, !0)
    }

    function l(a) {
        k(a, !1)
    }
    g.controls = a;
    g.describedBy = b;
    g.owns = d;
    g.setPopup = e;
    g.announce = f;
    g.notify = l
}), 98);
__d("Toggler", ["csx", "invariant", "$", "Arbiter", "ArbiterMixin", "CSS", "ContextualThing", "DOM", "DataStore", "Event", "Focus", "Keys", "Parent", "TabbableElements", "TimeSlice", "createArrayFromMixed", "emptyFunction", "ge", "getContextualParent", "getObjectValues", "killswitch", "mixin", "queryThenMutateDOM", "setImmediate"], (function(a, b, c, d, e, f, g, h, i) {
    var j = [],
        k, l = !1;

    function m() {
        l || (l = !0, c("setImmediate")(function() {
            l = !1
        }))
    }
    var n = function() {
            n = c("emptyFunction"), c("Event").listen(document.documentElement, "click", function(a) {
                if (l) return;
                var b = a.getTarget();
                j.forEach(function(a) {
                    a.clickedTarget = b, a.active && !a.sticky && !d("ContextualThing").containsIncludingLayers(a.getActive(), b) && !a.inTargetFlyout(b) && a.inActiveDialog() && !a.isIgnoredByModalLayer(b) && a.hide()
                })
            }, c("Event").Priority.URGENT)
        },
        o = function(e) {
            babelHelpers.inheritsLoose(b, e);

            function b() {
                var a;
                a = e.call(this) || this;
                a.active = null;
                a.togglers = {};
                a.setSticky(!1);
                j.push(babelHelpers.assertThisInitialized(a));
                a.subscribe(["show", "hide"], b.inform.bind(b));
                return n() || babelHelpers.assertThisInitialized(a)
            }
            var f = b.prototype;
            f.focusFirstTabbableDescendant = function(a, b) {
                if (!c("killswitch")("TOGGLER_FAST_SHOW")) {
                    b.$Toggler2 && b.$Toggler2.cancel();
                    var e = null;
                    b.$Toggler2 = c("queryThenMutateDOM")(function() {
                        var b = a.querySelector(".uiToggleFlyout");
                        b && (e = d("TabbableElements").findFirst(b) || b)
                    }, function() {
                        delete b.$Toggler2, e && (e.tabIndex == null && (e.tabIndex = -1), d("Focus").setWithoutOutline(e))
                    })
                } else {
                    var f = a.querySelector(".uiToggleFlyout");
                    if (f) {
                        f = d("TabbableElements").find(f)[0] || f;
                        f.tabIndex == null && (f.tabIndex = -1);
                        d("Focus").setWithoutOutline(f)
                    }
                }
            };
            f.show = function(a) {
                var b = p(this, a),
                    e = b.active;
                if (a !== e) {
                    e && b.hide();
                    b.active = a;
                    d("CSS").addClass(a, "openToggler");
                    e = c("DOM").scry(a, 'a[rel="toggle"]');
                    e.length > 0 && e[0].getAttribute("data-target") && d("CSS").removeClass(c("$")(e[0].getAttribute("data-target")), "toggleTargetClosed");
                    this.focusFirstTabbableDescendant(a, b);
                    e.length > 0 && (c("DOM").appendContent(a, b.getToggler("next")), c("DOM").prependContent(a, b.getToggler("prev")));
                    c("Event").listen(a, "keydown", function(d) {
                        if (c("Event").getKeyCode(d) === c("Keys").ESC && b.isShown()) {
                            var e = c("DOM").scry(a, 'a[rel="toggle"]')[0];
                            e && e.focus();
                            b.hide();
                            d.kill()
                        }
                    });
                    a.getAttribute("data-toggle-wc") && (b.__continuation = c("TimeSlice").getGuardedContinuation("Toggler.show inform"));
                    b.inform("show", b, "state")
                }
            };
            f.hide = function(a) {
                var b = p(this, a);
                b.$Toggler2 && b.$Toggler2.cancel();
                var e = b.active;
                if (e && (!a || a === e)) {
                    d("CSS").removeClass(e, "openToggler");
                    a = c("DOM").scry(e, 'a[rel="toggle"]');
                    a.length > 0 && a[0].getAttribute("data-target") && d("CSS").addClass(c("$")(a[0].getAttribute("data-target")), "toggleTargetClosed");
                    c("getObjectValues")(b.togglers).forEach(c("DOM").remove);
                    e.getAttribute("data-toggle-wc") && (b.__continuation = c("TimeSlice").getGuardedContinuation("Toggler.hide inform"));
                    b.inform("hide", b, "state");
                    b.active = null
                }
            };
            f.toggle = function(a) {
                var b = p(this, a);
                b.active === a ? b.hide() : b.show(a);
                m()
            };
            f.getActive = function() {
                return p(this).active
            };
            f.isShown = function() {
                return p(this).active && d("CSS").hasClass(p(this).active, "openToggler")
            };
            b.isNodeShown = function(a) {
                return d("CSS").hasClass(a, "openToggler")
            };
            f.inTargetFlyout = function(a) {
                var b = q(this.getActive());
                return Boolean(b && d("ContextualThing").containsIncludingLayers(b, a))
            };
            f.inActiveDialog = function() {
                var b = a.Dialog && a.Dialog.getCurrent();
                return !b || c("DOM").contains(b.getRoot(), this.getActive())
            };
            f.isIgnoredByModalLayer = function(a) {
                a = !!d("Parent").bySelector(a, "._3qw");
                var b = !!d("Parent").bySelector(this.getActive(), "._3qw");
                return a && !b
            };
            f.getToggler = function(a) {
                var b = p(this);
                b.togglers[a] || (b.togglers[a] = c("DOM").create("button", {
                    className: "hideToggler",
                    onfocus: function() {
                        var a = c("DOM").scry(b.active, 'a[rel="toggle"]')[0];
                        a && a.focus();
                        b.hide()
                    },
                    style: {
                        right: a === "next" ? "0" : ""
                    }
                }), b.togglers[a].setAttribute("type", "button"));
                return this.togglers[a]
            };
            f.setSticky = function(a) {
                var b = p(this);
                a = a !== !1;
                a !== b.sticky && (b.sticky = a, a ? b.$Toggler1 && b.$Toggler1.unsubscribe() : b.$Toggler1 = c("Arbiter").subscribe("pre_page_transition", b.hide.bind(b, null)));
                return b
            };
            f.setPrePageTransitionCallback = function(a) {
                var b = p(this);
                b.$Toggler1 && b.$Toggler1.unsubscribe();
                b.$Toggler1 = c("Arbiter").subscribe("pre_page_transition", a)
            };
            b.bootstrap = function(a) {
                a = a.parentNode;
                a != null || i(0, 3354);
                var c = b.getInstance(a);
                c != null || i(0, 3355);
                c.toggle(a)
            };
            b.createInstance = function(a) {
                var c = new b().setSticky(!0);
                d("DataStore").set(a, "toggler", c);
                return c
            };
            b.destroyInstance = function(a) {
                var b = d("DataStore").get(a, "toggler");
                b && b.$Toggler2 && b.$Toggler2.cancel();
                d("DataStore").remove(a, "toggler")
            };
            b.getInstance = function(a) {
                a = a;
                while (a) {
                    var e = d("DataStore").get(a, "toggler");
                    if (e) return e;
                    if (a instanceof Element)
                        if (d("CSS").hasClass(a, "uiToggleContext")) return b.createInstance(a);
                        else if (!c("killswitch")("JEWEL_TOGGLER_INSTANCE_FIXES") && d("CSS").hasClass(a, "uiToggleFlyout")) return b.createInstance(a).setSticky(!1);
                    a = c("getContextualParent")(a)
                }
                return k = k || new b()
            };
            b.listen = function(a, d, e) {
                return b.subscribe(c("createArrayFromMixed")(a), function(a, b) {
                    if (b.getActive() === d) {
                        if (b.__continuation) {
                            var c = b.__continuation;
                            delete b.__continuation;
                            return c(function() {
                                return e(a, b)
                            })
                        }
                        return e(a, b)
                    }
                })
            };
            return b
        }(c("mixin")(c("ArbiterMixin")));
    Object.assign(o, o.prototype, c("ArbiterMixin"));
    Object.assign(o, {
        subscribe: function(a) {
            return function(b, d) {
                b = c("createArrayFromMixed")(b);
                b.includes("show") && j.forEach(function(a) {
                    a.getActive() && setTimeout(d.bind(null, "show", a), 0)
                });
                return a(b, d)
            }
        }(o.subscribe.bind(o))
    });

    function p(a, b) {
        return a instanceof o ? a : o.getInstance(b)
    }

    function q(a) {
        a = c("DOM").scry(a, 'a[rel="toggle"]');
        return a.length > 0 && a[0].getAttribute("data-target") ? c("ge")(a[0].getAttribute("data-target")) : null
    }
    g["default"] = o
}), 98);
__d("getOverlayZIndex", ["Style"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        b = b;
        a = a;
        b = b || document.body;
        var d = [];
        while (a && a !== b) d.push(a), a = a.parentNode;
        if (a !== b) return 0;
        for (var a = d.length - 1; a >= 0; a--) {
            b = d[a];
            if (c("Style").get(b, "position") != "static") {
                b = parseInt(c("Style").get(b, "z-index"), 10);
                if (!isNaN(b)) return b
            }
        }
        return 0
    }
    g["default"] = a
}), 98);
__d("Button", ["csx", "cx", "invariant", "CSS", "DOM", "DataStore", "Event", "Parent", "emptyFunction", "isNode"], (function(a, b, c, d, e, f, g, h, i, j) {
    var k = "uiButtonDisabled",
        l = "uiButtonDepressed",
        m = "_42fr",
        n = "_42fs",
        o = "button:blocker",
        p = "href",
        q = "ajaxify";

    function r(a, b) {
        var e = d("DataStore").get(a, o);
        b ? e && (e.remove(), d("DataStore").remove(a, o)) : e || d("DataStore").set(a, o, c("Event").listen(a, "click", c("emptyFunction").thatReturnsFalse, c("Event").Priority.URGENT))
    }

    function s(a) {
        a = d("Parent").byClass(a, "uiButton") || d("Parent").bySelector(a, "._42ft");
        if (!a) throw new Error("invalid use case");
        return a
    }

    function t(a) {
        return c("DOM").isNodeOfType(a, "a")
    }

    function u(a) {
        return c("DOM").isNodeOfType(a, "button")
    }

    function v(a) {
        return d("CSS").matchesSelector(a, "._42ft")
    }
    var w = {
        getInputElement: function(a) {
            a = s(a);
            if (t(a)) throw new Error("invalid use case");
            if (u(a)) {
                a instanceof HTMLButtonElement || j(0, 21261);
                return a
            }
            return c("DOM").find(a, "input")
        },
        isEnabled: function(a) {
            return !(d("CSS").hasClass(s(a), k) || d("CSS").hasClass(s(a), m))
        },
        setEnabled: function(a, b) {
            a = s(a);
            var c = v(a) ? m : k;
            d("CSS").conditionClass(a, c, !b);
            if (t(a)) {
                c = a.getAttribute("href");
                var e = a.getAttribute("ajaxify"),
                    f = d("DataStore").get(a, p, "#"),
                    g = d("DataStore").get(a, q);
                b ? (c || a.setAttribute("href", f), !e && g && a.setAttribute("ajaxify", g), a.removeAttribute("tabIndex")) : (c && c !== f && d("DataStore").set(a, p, c), e && e !== g && d("DataStore").set(a, q, e), a.removeAttribute("href"), a.removeAttribute("ajaxify"), a.setAttribute("tabIndex", "-1"));
                r(a, b)
            } else {
                f = w.getInputElement(a);
                f.disabled = !b;
                r(f, b)
            }
        },
        setDepressed: function(a, b) {
            a = s(a);
            var c = v(a) ? n : l;
            d("CSS").conditionClass(a, c, b)
        },
        isDepressed: function(a) {
            a = s(a);
            var b = v(a) ? n : l;
            return d("CSS").hasClass(a, b)
        },
        setLabel: function(a, b) {
            a = s(a);
            if (v(a)) {
                var e = [];
                b && e.push(b);
                var f = c("DOM").scry(a, ".img");
                for (var g = 0; g < f.length; g++) {
                    var h = f[g],
                        i = h.parentNode;
                    i.classList && (i.classList.contains("_4o_3") || i.classList.contains("_-xe")) ? a.firstChild === i ? e.unshift(i) : e.push(i) : a.firstChild == h ? e.unshift(h) : e.push(h)
                }
                c("DOM").setContent(a, e)
            } else if (t(a)) {
                i = c("DOM").find(a, "span.uiButtonText");
                c("DOM").setContent(i, b)
            } else w.getInputElement(a).value = b;
            h = v(a) ? "_42fv" : "uiButtonNoText";
            d("CSS").conditionClass(a, h, !b)
        },
        getIcon: function(a) {
            a = s(a);
            return c("DOM").scry(a, ".img")[0]
        },
        setIcon: function(a, b) {
            if (b && !c("isNode")(b)) return;
            var e = w.getIcon(a);
            if (!b) {
                e && c("DOM").remove(e);
                return
            }
            d("CSS").addClass(b, "customimg");
            e != b && (e ? c("DOM").replace(e, b) : c("DOM").prependContent(s(a), b))
        }
    };
    a = w;
    g["default"] = a
}), 98);
__d("SVGChecker", [], (function(a, b, c, d, e, f) {
    e.exports = {
        isSVG: function(a) {
            return !!a.ownerSVGElement || a.tagName.toLowerCase() === "svg"
        },
        isDisplayed: function(a) {
            try {
                a = a.getBBox();
                if (a && (a.height === 0 || a.width === 0)) return !1
            } catch (a) {
                return !1
            }
            return !0
        }
    }
}), null);
__d("getOffsetParent", ["Style"], (function(a, b, c, d, e, f) {
    function g(a) {
        a = a.parentNode;
        if (!a || a === document.documentElement) return document.documentElement;
        return b("Style").get(a, "position") !== "static" ? a : a === document.body ? document.documentElement : g(a)
    }
    e.exports = g
}), null);
__d("ContextualLayer", ["invariant", "ARIA", "Arbiter", "Bootloader", "CSS", "ContextualLayerAlignmentEnum", "ContextualLayerPositionEnum", "ContextualThing", "DOM", "DataStore", "Event", "Layer", "Locale", "Parent", "Rect", "SVGChecker", "Scroll", "Style", "Vector", "containsNode", "cr:971473", "emptyFunction", "getOffsetParent", "getOrCreateDOMID", "getOverlayZIndex", "getOwnObjectValues", "gkx", "isElementNode", "killswitch", "removeFromArray", "throttle"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        return a.getPosition() === "left" || a.isVertical() && a.getAlignment() === "right"
    }
    a = function(a) {
        "use strict";
        babelHelpers.inheritsLoose(c, a);

        function c() {
            return a.apply(this, arguments) || this
        }
        var d = c.prototype;
        d._configure = function(b, c) {
            b.dialogRole !== "dialog" && (this._dialogRole = b.dialogRole), b.shouldSetARIAProperties === !1 && (this._shouldSetARIAProperties = b.shouldSetARIAProperties), b.label && (this._label = b.label), b.labelledBy && (this._labelledBy = b.labelledBy), a.prototype._configure.call(this, b, c), b.context ? this.setContext(b.context) : b.contextID ? this._setContextID(b.contextID) : b.contextSelector && (this._setContextSelector(b.contextSelector), this._setARIAProperties()), this.setPosition(b.position), this.setAlignment(b.alignment), this.setOffsetX(b.offsetX), this.setOffsetY(b.offsetY), this.setArrowDimensions(b.arrowDimensions), this._content = c
        };
        d._getDefaultBehaviors = function() {
            var d = c.getDefaultBehaviorsAsObject();
            return a.prototype._getDefaultBehaviors.call(this).concat(b("getOwnObjectValues")(d))
        };
        d._buildWrapper = function(a, c) {
            this._contentWrapper = b("DOM").create("div", {
                className: "uiContextualLayer"
            }, c);
            this._dialogRole && this._contentWrapper.setAttribute("role", this._dialogRole);
            this._labelledBy ? this._contentWrapper.setAttribute("aria-labelledby", this._labelledBy) : this._label && this._contentWrapper.setAttribute("aria-label", this._label);
            this._dialogRole === "alert" && this._contentWrapper.setAttribute("aria-atomic", "true");
            return b("DOM").create("div", {
                className: "uiContextualLayerPositioner",
                "data-testid": a["data-testid"]
            }, this._contentWrapper)
        };
        d.getInsertParent = function() {
            var c = this._insertParent;
            if (!c) {
                var d = this.getContext();
                d && (c = b("Parent").byClass(d, "uiContextualLayerParent"))
            }
            return c || a.prototype.getInsertParent.call(this)
        };
        d.setContent = function(a) {
            this._content = a;
            b("DOM").setContent(this._contentWrapper, this._content);
            this._shown && this.updatePosition();
            return this
        };
        d.setContext = function(a) {
            return this.setContextWithBounds(a, null)
        };
        d.setContextWithBounds = function(a, c) {
            if (this._contextNode === a && c && this._contextBounds && c.isEqualTo(this._contextBounds)) return this;
            this._contextNode = a;
            var d = c && this._contextBounds && c.t === this._contextBounds.t && c.r === this._contextBounds.r && c.b === this._contextBounds.b && c.l === this._contextBounds.l;
            if (d) return this;
            this._contextBounds = c || null;
            this._contextSelector = "#" + b("getOrCreateDOMID")(a);
            this._contextScrollParent = null;
            this._shown && (b("ContextualThing").register(this.getRoot(), this._contextNode), this.updatePosition());
            this._setParentSubscription();
            this._setARIAProperties();
            return this
        };
        d.shouldSetARIAProperties = function(a) {
            this._shouldSetARIAProperties = a;
            return this
        };
        d._setARIAProperties = function() {
            var a = this;
            if (!this._shouldSetARIAProperties) return this;
            this._dialogRole === "dialog" ? b("ARIA").setPopup(this.getCausalElement(), this.getRoot()) : this._dialogRole === "region" && b("Bootloader").loadModules(["ContextualLayerInlineTabOrder"], function(b) {
                a.hasBehavior(b) || a.enableBehavior(b)
            }, "ContextualLayer");
            return this
        };
        d._setContextID = function(a) {
            this._contextSelector = "#" + a, this._contextNode = null
        };
        d._setContextSelector = function(a) {
            this._contextSelector = a, this._contextNode = null
        };
        d.getCausalElement = function() {
            return a.prototype.getCausalElement.call(this) || this.getContext()
        };
        d._setParentSubscription = function() {
            var a = this.getContext(),
                c = null;
            while (a != null) {
                c = b("DataStore").get(a, "layer");
                if (c && typeof c === "object") break;
                a = a.parentNode
            }
            if (c === this._parentLayer) return;
            this._parentLayer && this._parentSubscription && (this._parentLayer.unsubscribe(this._parentSubscription), this._parentSubscription = null);
            c && (this._parentSubscription = c.subscribe("hide", this.hide.bind(this)));
            this._parentLayer = c
        };
        d.setPosition = function(a) {
            this.getOrientation().setDefaultPosition(a) && (this._shown && this.updatePosition());
            return this
        };
        d.setAlignment = function(a) {
            this.getOrientation().setDefaultAlignment(a) && (this._shown && this.updatePosition());
            return this
        };
        d.setOffsetX = function(a) {
            this.getOrientation().setDefaultOffsetX(a) && (this._shown && this.updatePosition());
            return this
        };
        d.setArrowDimensions = function(a) {
            a && this.getOrientation().setArrowOffset(a.offset) && (this._shown && this.updatePosition());
            return this
        };
        d.setOffsetY = function(a) {
            this.getOrientation().setDefaultOffsetY(a) && (this._shown && this.updatePosition());
            return this
        };
        d.getPosition = function() {
            return this.getOrientation().getPosition()
        };
        d.getOrientation = function() {
            this._orientation || (this._orientation = new l());
            return this._orientation
        };
        d.getContentRoot = function() {
            return this._contentWrapper
        };
        d.getContent = function() {
            return this._content
        };
        d.getContext = function() {
            this._contextNode || (this._contextSelector != null || g(0, 11711), this._contextNode = b("DOM").find(document, this._contextSelector));
            return this._contextNode
        };
        d.getContextBounds = function(a) {
            if (this._contextBounds) return this._contextBounds.convertTo(a);
            var c = this.getContext();
            return b("Rect").newFromVectors(b("Vector").getElementPosition(c, a), b("Vector").getElementDimensions(c))
        };
        d.getContextScrollParent = function() {
            !this._contextScrollParent ? this._contextScrollParent = b("Style").getScrollParent(this.getContext()) : b("isElementNode")(this._contextScrollParent) && !b("containsNode")(document.documentElement, this._contextScrollParent) && (this._contextScrollParent = b("Style").getScrollParent(this.getContext()));
            return this._contextScrollParent
        };
        d.setInsertParent = function(b) {
            this._insertScrollParent = null;
            return a.prototype.setInsertParent.call(this, b)
        };
        d.getInsertScrollParent = function() {
            this._insertScrollParent || (this._insertScrollParent = b("Style").getScrollParent(this.getInsertParent()));
            return this._insertScrollParent
        };
        d.show = function() {
            var c = this;
            if (this._shown) return this;
            a.prototype.show.call(this);
            b("Arbiter").inform("contextualLayer/toggle", {
                show: !0,
                contentRoot: this.getRoot()
            });
            this._shown && (b("ContextualThing").register(this.getRoot(), this.getContext()), i.push(this), this._resizeListener = this._resizeListener || b("Event").listen(window, "resize", b("throttle")(function() {
                c._shown && c.updatePosition()
            })));
            return this
        };
        d.finishHide = function() {
            b("removeFromArray")(i, this);
            this._resizeListener && this._resizeListener.remove();
            this._resizeListener = null;
            this._insertScrollParent = null;
            b("Arbiter").inform("contextualLayer/toggle", {
                show: !1,
                contentRoot: this.getRoot()
            });
            return a.prototype.finishHide.call(this)
        };
        d.isFixed = function() {
            return b("Style").isFixed(this.getContext()) && !b("Style").isFixed(this.getInsertParent())
        };
        d.updatePosition = function() {
            var a = this.getContext();
            if (!a) return !1;
            var c = this.isFixed();
            if (!c && !(a.offsetParent || b("SVGChecker").isSVG(a) && b("SVGChecker").isDisplayed(a))) return !1;
            var d = this.getRoot(),
                e = !b("killswitch")("CONTEXTUAL_POSITIONING_MOBILE_FIX"),
                f = e ? b("Vector").getLayoutViewportDimensions().x : b("Vector").getViewportDimensions().x;
            b("Style").set(d, "width", f + "px");
            var g = this.getOrientation();
            this.inform("adjust", g.reset());
            if (!g.isValid()) return !1;
            this._updateWrapperPosition(g);
            this._updateWrapperClass(g);
            b("CSS").conditionClass(d, "uiContextualLayerPositionerFixed", c);
            var i = c ? "viewport" : "document",
                j = c ? document.documentElement : b("getOffsetParent")(d);
            if (c && e) c = new(b("Vector"))(0, 0), e = f;
            else if (j === document.documentElement) c = new(b("Vector"))(0, 0), e = document.documentElement.clientWidth;
            else if (!d.offsetParent) return !1;
            else c = b("Vector").getElementPosition(j, i), e = j.offsetWidth, j !== document.body && (c = c.sub(new(b("Vector"))(b("Scroll").getLeft(j), b("Scroll").getTop(j))));
            f = this.getContextBounds(i);
            j = f.l - c.x;
            i = f.t - c.y;
            c = f.h();
            f = f.w();
            var k = b("Locale").isRTL();
            g.getPosition() === "below" && (i += c);
            (g.getPosition() === "right" || g.isVertical() && g.getAlignment() === "right") != k && (j += f);
            c = g.getOffsetX();
            g.isVertical() && g.getAlignment() === "center" && (c += (f - this.getContentRoot().offsetWidth) / 2);
            k && (c *= -1);
            f = "left";
            j = Math.floor(j + c);
            h(g) !== k && (f = "right", j = e - j);
            b("Style").set(d, f, j + "px");
            b("Style").set(d, f === "left" ? "right" : "left", "");
            c = this.getInsertScrollParent();
            k = 0;
            c !== window ? (e = c.clientWidth, k = b("Vector").getElementPosition(c).x) : e = document.documentElement.clientWidth;
            j = b("Vector").getElementPosition(d).x - k;
            c = 0;
            k = window.devicePixelRatio !== Math.round(window.devicePixelRatio);
            c = k ? 1 : 0;
            b("gkx")("1908135") && (c = 1);
            f === "left" && e - j > 0 ? b("Style").set(d, "width", e - j - c + "px") : f === "right" && j + d.offsetWidth > 0 ? b("Style").set(d, "width", j + d.offsetWidth - c + "px") : b("Style").set(d, "width", "");
            b("Style").set(d, "top", i + g.getOffsetY() + "px");
            k = b("getOverlayZIndex")(a, this.getInsertParent());
            b("Style").set(d, "z-index", k > 200 ? k : "");
            this.inform("reposition", g);
            return !0
        };
        d._updateWrapperPosition = function(a) {
            var c = a.getPosition() === "above";
            b("Style").set(this._contentWrapper, "bottom", c ? "0" : null);
            c = b("Locale").isRTL() ? "left" : "right";
            a = h(a);
            b("Style").set(this._contentWrapper, c, a ? "0" : null)
        };
        d._updateWrapperClass = function(a) {
            a = a.getClassName();
            if (a === this._orientationClass) return;
            this._orientationClass && b("CSS").removeClass(this._contentWrapper, this._orientationClass);
            this._orientationClass = a;
            b("CSS").addClass(this._contentWrapper, a)
        };
        d.simulateOrientation = function(a, c) {
            a = a.getClassName();
            if (a === this._orientationClass) return c();
            else {
                this._orientationClass && b("CSS").removeClass(this._contentWrapper, this._orientationClass);
                b("CSS").addClass(this._contentWrapper, a);
                c = c();
                b("CSS").removeClass(this._contentWrapper, a);
                this._orientationClass && b("CSS").addClass(this._contentWrapper, this._orientationClass);
                return c
            }
        };
        d.destroy = function() {
            a.prototype.destroy.call(this);
            this._contentWrapper = null;
            this._content = null;
            return this
        };
        d.getArrowDimensions = function() {
            return this._config.arrowDimensions || {
                offset: 0,
                length: 0
            }
        };
        c.getDefaultBehaviorsAsObject = function() {
            return b("cr:971473") == null ? {} : {
                LayerHideOnTransition: b("cr:971473")
            }
        };
        return c
    }(b("Layer"));
    var i = [];
    b("Arbiter").subscribe("reflow", function() {
        i.forEach(function(a) {
            a.updatePosition() === !1 && a.hide()
        })
    });
    Object.assign(a.prototype, {
        _contentWrapper: null,
        _content: null,
        _contextNode: null,
        _contextBounds: null,
        _contextSelector: null,
        _dialogRole: "dialog",
        _label: null,
        _labelledBy: [],
        _parentLayer: null,
        _parentSubscription: null,
        _orientation: null,
        _orientationClass: null,
        _shouldSetARIAProperties: !0
    });
    var j = b("emptyFunction").thatReturnsArgument,
        k = b("emptyFunction").thatReturnsArgument,
        l = function() {
            "use strict";

            function a() {
                this._default = {
                    _position: "above",
                    _alignment: "left",
                    _offsetX: 0,
                    _offsetY: 0,
                    _valid: !0,
                    _preferMoreContentShownRect: !1
                }, this.reset()
            }
            var b = a.prototype;
            b.setPosition = function(a) {
                this._position = j(a);
                return this
            };
            b.setAlignment = function(a) {
                this._alignment = k(a);
                return this
            };
            b.getOppositePosition = function() {
                return a.OPPOSITE[this.getPosition()]
            };
            b.invalidate = function() {
                this._valid = !1;
                return this
            };
            b.getPosition = function() {
                return this._position || "above"
            };
            b.getAlignment = function() {
                return this._alignment || "left"
            };
            b.getOffsetX = function() {
                var a = this._offsetX || 0;
                !this.isVertical() ? this._default._position !== this._position && (a *= -1) : this._default._alignment !== this._alignment && (a *= -1);
                return a
            };
            b.getOffsetY = function() {
                var a = this._offsetY || 0;
                this.isVertical() && this._default._position !== this._position && (a *= -1);
                return a
            };
            b.getClassName = function() {
                var a = this.getAlignment(),
                    b = this.getPosition();
                if (b === "below")
                    if (a === "left") return "uiContextualLayerBelowLeft";
                    else if (a === "right") return "uiContextualLayerBelowRight";
                else return "uiContextualLayerBelowCenter";
                else if (b === "above")
                    if (a === "left") return "uiContextualLayerAboveLeft";
                    else if (a === "right") return "uiContextualLayerAboveRight";
                else return "uiContextualLayerAboveCenter";
                else if (b === "left") return "uiContextualLayerLeft";
                else return "uiContextualLayerRight"
            };
            b.isValid = function() {
                return this._valid
            };
            b.isVertical = function() {
                return this.getPosition() === "above" || this.getPosition() === "below"
            };
            b.reset = function() {
                Object.assign(this, this._default);
                return this
            };
            b.setDefaultPosition = function(a) {
                var b = this._default._position;
                this._default._position = j(a);
                return b !== a
            };
            b.setDefaultAlignment = function(a) {
                var b = this._default._alignment;
                this._default._alignment = k(a);
                return b !== a
            };
            b.setDefaultOffsetX = function(a) {
                var b = this._default._offsetX;
                this._default._offsetX = a;
                return b !== a
            };
            b.setArrowOffset = function(a) {
                var b = this._default._arrowOffset;
                this._default._arrowOffset = a;
                return b !== a
            };
            b.getArrowOffset = function() {
                return this._default._arrowOffset || 0
            };
            b.setDefaultOffsetY = function(a) {
                var b = this._default._offsetY;
                this._default._offsetY = a;
                return b !== a
            };
            b.setPreferMoreContentShownRect = function(a) {
                var b = this._default._preferMoreContentShownRect;
                this._default._preferMoreContentShownRect = a;
                return b !== a
            };
            b.getPreferMoreContentShownRect = function() {
                return this._default._preferMoreContentShownRect
            };
            return a
        }();
    l.OPPOSITE = {
        above: "below",
        below: "above",
        left: "right",
        right: "left"
    };
    e.exports = a
}), null);
__d("LayerBounds", ["Locale", "Rect", "ViewportBounds", "containsNode", "ge", "getOverlayZIndex"], (function(a, b, c, d, e, f) {
    a = {
        getViewportRectForContext: function(a) {
            var c = b("ge")("globalContainer");
            c = c && b("containsNode")(c, a) || b("getOverlayZIndex")(a) < 300;
            a = b("Rect").getViewportWithoutScrollbarsBounds();
            c && (a.t += b("ViewportBounds").getTop(), b("Locale").isRTL() ? (a.r -= b("ViewportBounds").getLeft(), a.l += b("ViewportBounds").getRight()) : (a.r -= b("ViewportBounds").getRight(), a.l += b("ViewportBounds").getLeft()));
            return a
        }
    };
    e.exports = a
}), null);
__d("ContextualLayerDimensions", ["LayerBounds", "Locale", "Rect", "Vector"], (function(a, b, c, d, e, f) {
    a = {
        getViewportRect: function(a) {
            return b("LayerBounds").getViewportRectForContext(a.getContext())
        },
        getLayerRect: function(a, c) {
            var d = a.getContextBounds("viewport"),
                e = a.simulateOrientation(c, function() {
                    return b("Vector").getElementDimensions(a.getContentRoot())
                }),
                f = d.t + c.getOffsetY();
            c.getPosition() === "above" ? f -= e.y : c.getPosition() === "below" && (f += d.b - d.t);
            var g = d.l + c.getOffsetX();
            d = d.r - d.l;
            if (c.isVertical()) {
                var h = c.getAlignment();
                h === "center" ? g += (d - e.x) / 2 : h === "right" !== b("Locale").isRTL() ? g += d - e.x + c.getArrowOffset() : g -= c.getArrowOffset()
            } else c.getPosition() === "right" !== b("Locale").isRTL() ? g += d : g -= e.x;
            return new(b("Rect"))(f, g + e.x, f + e.y, g, "viewport")
        }
    };
    e.exports = a
}), null);
__d("abstractMethod", ["invariant"], (function(a, b, c, d, e, f, g, h) {
    "use strict";

    function a(a, b) {
        h(0, 1537, a, b)
    }
    g["default"] = a
}), 98);
__d("AbstractContextualDialogArrowBehavior", ["cx", "CSS", "DOM", "Locale", "Style", "Vector", "abstractMethod"], (function(a, b, c, d, e, f, g) {
    var h = {
            bottom: "_53ik",
            top: "_53il",
            right: "_53im",
            left: "_53in"
        },
        i = {
            above: "bottom",
            below: "top",
            left: "right",
            right: "left"
        };
    a = function() {
        "use strict";

        function a(a) {
            this.__layer = this._layer = a
        }
        var c = a.prototype;
        c.enable = function() {
            this._subscription = this._layer.subscribe(["adjust", "reposition"], this._handle.bind(this))
        };
        c.disable = function() {
            this._subscription.unsubscribe(), this._subscription = null
        };
        c.__getArrow = function() {
            return b("abstractMethod")("AbstractContextualDialogArrowBehavior", "__getArrow")
        };
        c._handle = function(a, b) {
            a === "adjust" ? this._repositionArrow(b) : this._repositionRoot(b)
        };
        c._repositionRoot = function(a) {
            var c = a.getAlignment();
            if (c == "center") return;
            var d = this._layer.getRoot(),
                e = this._layer.getContext();
            a = a.isVertical();
            var f = this._layer.getArrowDimensions(),
                g = f.offset;
            f = f.length;
            e = b("Vector").getElementDimensions(e);
            e = a ? e.x : e.y;
            if (e >= f + g * 2) return;
            f = f / 2 + g;
            g = e / 2;
            e = parseInt(f - g, 10);
            if (a) {
                f = null;
                c == "left" ? f = b("Locale").isRTL() ? "right" : "left" : f = b("Locale").isRTL() ? "left" : "right";
                g = parseInt(b("Style").get(d, f), 10);
                b("Style").set(d, f, g - e + "px")
            } else {
                a = parseInt(b("Style").get(d, "top"), 10);
                b("Style").set(d, "top", a - e + "px")
            }
        };
        c._repositionArrow = function(c) {
            var d = this._layer.getContentRoot(),
                e = c.getPosition(),
                f = i[e];
            for (var g in h) b("CSS").conditionClass(d, h[g], f === g);
            if (e == "none") return;
            this._arrow || (this._arrow = this.__getArrow());
            b("DOM").contains(d, this._arrow) || b("DOM").appendContent(d, this._arrow);
            b("Style").set(this._arrow, "top", "");
            b("Style").set(this._arrow, "left", "");
            b("Style").set(this._arrow, "right", "");
            b("Style").set(this._arrow, "margin", "");
            f = a.getOffsetPercent(c);
            g = a.getOffset(c, f, this._layer);
            e = a.getOffsetSide(c);
            b("Style").set(this._arrow, e, f + "%");
            b("Style").set(this._arrow, "margin-" + e, g + "px")
        };
        a.getOffsetPercent = function(a) {
            var b = a.getAlignment();
            a = a.getPosition();
            if (a == "above" || a == "below")
                if (b == "center") return 50;
                else if (b == "right") return 100;
            return 0
        };
        a.getOffsetSide = function(a) {
            a = a.isVertical();
            return a ? b("Locale").isRTL() ? "right" : "left" : "top"
        };
        a.getOffset = function(a, b, c) {
            c = c.getArrowDimensions();
            var d = c.offset;
            c = c.length;
            a = a.getAlignment();
            d = a == "center" ? 0 : d;
            d += c * b / 100;
            a != "left" && (d *= -1);
            return d
        };
        return a
    }();
    e.exports = a
}), null);
__d("flattenArray", [], (function(a, b, c, d, e, f) {
    function a(a) {
        var b = [];
        g(a, b);
        return b
    }

    function g(a, b) {
        var c = a.length,
            d = 0;
        while (c--) {
            var e = a[d++];
            Array.isArray(e) ? g(e, b) : b.push(e)
        }
    }
    f["default"] = a
}), 66);
__d("JSXDOM", ["DOM", "FbtResultBase", "flattenArray"], (function(a, b, c, d, e, f) {
    a = ["a", "blockquote", "br", "button", "canvas", "checkbox", "dd", "div", "dl", "dt", "em", "form", "h1", "h2", "h3", "h4", "h5", "h6", "hr", "i", "iframe", "img", "input", "label", "li", "option", "p", "pre", "select", "span", "strong", "table", "tbody", "thead", "td", "textarea", "th", "tr", "ul", "video"];
    var g = {};
    a.forEach(function(a) {
        var c = function(c, d) {
            arguments.length > 2 && (d = Array.prototype.slice.call(arguments, 1));
            !d && c && (d = c.children, delete c.children);
            d && (d = Array.isArray(d) ? d : [d], d = d.map(function(a) {
                return a instanceof b("FbtResultBase") ? a.flattenToArray() : a
            }), d = b("flattenArray")(d));
            return b("DOM").create(a, c, d)
        };
        g[a] = c
    });
    e.exports = g
}), null);
__d("ContextualDialogArrow", ["cx", "AbstractContextualDialogArrowBehavior", "CSS", "JSXDOM"], (function(a, b, c, d, e, f, g, h) {
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        var e = b.prototype;
        e.__getArrow = function() {
            return c("JSXDOM").i({
                className: "_53io"
            })
        };
        e.enable = function() {
            a.prototype.enable.call(this);
            var b = this.__layer.getContentRoot();
            d("CSS").addClass(b, "_5v-0")
        };
        e.disable = function() {
            a.prototype.disable.call(this);
            var b = this.__layer.getContentRoot();
            d("CSS").removeClass(b, "_5v-0")
        };
        return b
    }(c("AbstractContextualDialogArrowBehavior"));
    g["default"] = a
}), 98);
__d("isKeyActivation", ["Keys"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = 0,
            d = a.charCode;
        a = a.keyCode;
        d != null && d !== 0 ? b = d : a != null && a !== 0 && (b = a);
        return [c("Keys").RETURN, c("Keys").SPACE].includes(b)
    }
    g["default"] = a
}), 98);
__d("RTLKeys", ["Keys", "Locale"], (function(a, b, c, d, e, f, g) {
    var h = null;

    function i() {
        h === null && (h = d("Locale").isRTL());
        return h
    }
    a = babelHelpers.objectWithoutPropertiesLoose(c("Keys"), ["RIGHT", "LEFT"]);
    var j = babelHelpers["extends"]({}, a, {
        REAL_RIGHT: c("Keys").RIGHT,
        REAL_LEFT: c("Keys").LEFT,
        getLeft: function() {
            return i() ? j.REAL_RIGHT : j.REAL_LEFT
        },
        getRight: function() {
            return i() ? j.REAL_LEFT : j.REAL_RIGHT
        }
    });
    b = j;
    g["default"] = b
}), 98);
__d("shield", [], (function(a, b, c, d, e, f) {
    function a(a, b) {
        for (var c = arguments.length, d = new Array(c > 2 ? c - 2 : 0), e = 2; e < c; e++) d[e - 2] = arguments[e];
        if (typeof a !== "function") throw new TypeError("shield expects a function as the first argument");
        return function() {
            return a.apply(b, d)
        }
    }
    f["default"] = a
}), 66);